
package Demo;

/**
 *
 * @author Lunar
 */


public class NocitMain
{
  public static void main(String[] args)
  {
    NocitWindow ui = new NocitWindow();
    
    NocitInputs inputs = new NocitInputs();
    
    NocitControl control = new NocitControl(ui, inputs);
  }
}
