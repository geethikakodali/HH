/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Demo;

/**
 *
 * @author Lunar
 */


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import javax.swing.JProgressBar;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.optimization.OptimizationException;
import org.apache.commons.math.optimization.fitting.CurveFitter;
import org.apache.commons.math.optimization.fitting.ParametricRealFunction;
import org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer;
import org.apache.commons.math.stat.descriptive.DescriptiveStatistics;

public class NocitAlgorithm
{
  private static class Peak
  {
    private int allele;
    private int height;
    
    Peak(int assignallele, int assignheight)
    {
      this.allele = assignallele;
      this.height = assignheight;
    }
    
    public int getAllele()
    {
      return this.allele;
    }
    
    public int getHeight()
    {
      return this.height;
    }
    
    public String toString()
    {
      return this.allele + "," + this.height;
    }
  }
  
  private static class AMEL_Peak
  {
    private String allele;
    private int height;
    
    public AMEL_Peak(String assignallele, int assignheight)
    {
      this.allele = assignallele;
      this.height = assignheight;
    }
    
    public String getAllele()
    {
      return this.allele;
    }
    
    public int getHeight()
    {
      return this.height;
    }
    
    public String toString()
    {
      return this.allele + "," + this.height;
    }
  }
  
  private static class Callable_loci_object
  {
    private double thread_value;
    private double max_val;
    private Set<Integer> max_alls;
    
    Callable_loci_object(double threadval, double maxval, Set<Integer> maxalls)
    {
      this.thread_value = threadval;
      this.max_val = maxval;
      this.max_alls = maxalls;
    }
    
    public Set<Integer> getmaxalls()
    {
      return this.max_alls;
    }
    
    public double getmaxvalue()
    {
      return this.max_val;
    }
    
    public double getvalue()
    {
      return this.thread_value;
    }
  }
  
  private static class Callable_amel_object
  {
    private double thread_value;
    private double max_val;
    private Set<String> max_alls;
    
    Callable_amel_object(double threadval, double maxval, Set<String> maxalls)
    {
      this.thread_value = threadval;
      this.max_val = maxval;
      this.max_alls = maxalls;
    }
    
    public Set<String> getmaxalls()
    {
      return this.max_alls;
    }
    
    public double getmaxvalue()
    {
      return this.max_val;
    }
    
    public double getvalue()
    {
      return this.thread_value;
    }
  }
  
  private static double[] calcSlopeValue(String locusname, double massvalue, HashMap<String, double[]> meanslope, HashMap<String, double[]> stddevslope)
  {
    String locus_name = locusname;
    double mass_value = massvalue;
    HashMap<String, double[]> mean_slope = meanslope;
    HashMap<String, double[]> stddev_slope = stddevslope;
    
    double a_mean = ((double[])mean_slope.get(locus_name))[0];
    double b_mean = ((double[])mean_slope.get(locus_name))[1];
    double a_stddev = ((double[])stddev_slope.get(locus_name))[0];
    double b_stddev = ((double[])stddev_slope.get(locus_name))[1];
    
    double mean = a_mean * mass_value + b_mean;
    double stddev = a_stddev * mass_value + b_stddev;
    
    return new double[] { mean, stddev };
  }
  
  private static double calcExpValue(String locusname, HashMap<String, double[]> locushashmap, double xvalue)
  {
    String locus_name = locusname;
    double x_value = xvalue;
    HashMap<String, double[]> locus_hashmap = locushashmap;
    
    double a = ((double[])locus_hashmap.get(locus_name))[0];
    double b = ((double[])locus_hashmap.get(locus_name))[1];
    
    double expvalue = a * Math.exp(b * x_value);
    
    return expvalue;
  }
  
  private static double calcTwoExpValue(String locusname, HashMap<String, double[]> locushashmap, double xvalue)
  {
    String locus_name = locusname;
    double x_value = xvalue;
    HashMap<String, double[]> locus_hashmap = locushashmap;
    
    double a = ((double[])locus_hashmap.get(locus_name))[0];
    double b = ((double[])locus_hashmap.get(locus_name))[1];
    double c = ((double[])locus_hashmap.get(locus_name))[2];
    
    double twoexpvalue = a * Math.exp(b * x_value) + c;
    
    return twoexpvalue;
  }
  
  private static class CalibDataCollection
  {
    private String calib_path;
    private HashSet<String> calibLoci;
    private HashSet<Double> masses;
    private LinkedHashMap<String, LinkedHashMap<Integer, Double>> freq_table;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> trueCalibData;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> noiseCalibData;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> rstutterCalibData;
    private HashMap<Double, HashMap<String, ArrayList<Double>>> fstutterCalibData;
    private HashMap<Double, HashMap<String, Double>> rstutterDOCalibData;
    private HashMap<Double, HashMap<String, Double>> fstutterDOCalibData;
    private HashMap<Double, HashMap<String, Double>> dropoutCalibData;
    
    CalibDataCollection(String calibpath, LinkedHashMap<String, LinkedHashMap<Integer, Double>> freqtable)
    {
      this.calib_path = calibpath;
      this.freq_table = freqtable;
      this.dropoutCalibData = new HashMap();
      this.rstutterDOCalibData = new HashMap();
      this.fstutterDOCalibData = new HashMap();
      this.rstutterCalibData = new HashMap();
      this.fstutterCalibData = new HashMap();
      this.noiseCalibData = new HashMap();
      this.trueCalibData = new HashMap();
      this.calibLoci = new HashSet();
      this.masses = new HashSet();
      
      HashMap<Double, HashMap<String, ArrayList<Integer>>> trueValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> noiseValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Double>>> rstutterValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Double>>> fstutterValues = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> rstutterDO = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> fstutterDO = new HashMap();
      HashMap<Double, HashMap<String, ArrayList<Integer>>> dropout = new HashMap();
      try
      {
        NocitAlgorithm.OpenAndReadFile calibFile = new NocitAlgorithm.OpenAndReadFile(this.calib_path);
        String[] calibFileLines = calibFile.FileContents();
        for (int i = 1; i < calibFileLines.length; i++)
        {
          String line = calibFileLines[i];
          String[] lineParts = line.split(",");
          String locus = lineParts[4];
          this.calibLoci.add(locus);
          double mass = Double.parseDouble(lineParts[1]);
          this.masses.add(Double.valueOf(mass));
        }
        for (Iterator i$ = this.masses.iterator(); i$.hasNext();)
        {
            double mass = ((Double)i$.next()).doubleValue();
          trueValues.put(Double.valueOf(mass), new HashMap());
          noiseValues.put(Double.valueOf(mass), new HashMap());
          rstutterValues.put(Double.valueOf(mass), new HashMap());
          fstutterValues.put(Double.valueOf(mass), new HashMap());
          dropout.put(Double.valueOf(mass), new HashMap());
          rstutterDO.put(Double.valueOf(mass), new HashMap());
          fstutterDO.put(Double.valueOf(mass), new HashMap());
          this.dropoutCalibData.put(Double.valueOf(mass), new HashMap());
          this.rstutterDOCalibData.put(Double.valueOf(mass), new HashMap());
          this.fstutterDOCalibData.put(Double.valueOf(mass), new HashMap());
          this.trueCalibData.put(Double.valueOf(mass), new HashMap());
          this.noiseCalibData.put(Double.valueOf(mass), new HashMap());
          this.rstutterCalibData.put(Double.valueOf(mass), new HashMap());
          this.fstutterCalibData.put(Double.valueOf(mass), new HashMap());
          for (String locus : this.calibLoci)
          {
            ((HashMap)trueValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)noiseValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)rstutterValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)fstutterValues.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)dropout.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)rstutterDO.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)fstutterDO.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)this.trueCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)this.noiseCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)this.rstutterCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList());
            ((HashMap)this.fstutterCalibData.get(Double.valueOf(mass))).put(locus, new ArrayList());
          }
        }
        //double mass;
        String locus;
        double mass;
        for (int i = 1; i < calibFileLines.length; i++)
        {
          String line = calibFileLines[i];
          String[] lineParts = line.split(",");
          List<String> line_refresh = new ArrayList();
          for (String element : lineParts) {
            if (element != null) {
              line_refresh.add(element);
            }
          }
          locus = (String)line_refresh.get(4);
          mass = Double.parseDouble((String)line_refresh.get(1));
          if (!locus.contentEquals("AMEL"))
          {
            ArrayList<NocitAlgorithm.Peak> loci_peaks = new ArrayList();
            ArrayList<Integer> loci_alleles = new ArrayList();
            ArrayList<NocitAlgorithm.Peak> loci_peaks_refresh = new ArrayList();
            ArrayList<Integer> loci_alleles_refresh = new ArrayList();
            ArrayList<Integer> peakalleles_deleted = new ArrayList();
            ArrayList<NocitAlgorithm.Peak> peaks_tobedeleted = new ArrayList();
            Set<Integer> trueAlleles = new HashSet();
            Set<Integer> true_Stutter_Alleles = new HashSet();
            double tallele1 = Double.parseDouble((String)line_refresh.get(2));
            int trueallele1 = (int)Math.round(tallele1 * 10.0D);
            double tallele2 = Double.parseDouble((String)line_refresh.get(3));
            int trueallele2 = (int)Math.round(tallele2 * 10.0D);
            if (trueallele1 != trueallele2)
            {
              trueAlleles.add(Integer.valueOf(trueallele1));
              trueAlleles.add(Integer.valueOf(trueallele2));
              
              int j = 6;
              while (j < line_refresh.size())
              {
                if (!((String)line_refresh.get(j)).equals("OL"))
                {
                  double a = Double.parseDouble((String)line_refresh.get(j));
                  int allele = (int)Math.round(a * 10.0D);
                  int height = Integer.parseInt((String)line_refresh.get(j + 2));
                  NocitAlgorithm.Peak peakobject = new NocitAlgorithm.Peak(allele, height);
                  loci_peaks.add(peakobject);
                  loci_alleles.add(Integer.valueOf(peakobject.getAllele()));
                }
                j += 3;
              }
              for (Iterator i$ = loci_peaks.iterator(); i$.hasNext();)
              {
                  Peak peakobj1 = (NocitAlgorithm.Peak)i$.next();
                  int allele1 = peakobj1.getAllele();
                int count = Collections.frequency(loci_alleles, Integer.valueOf(allele1));
                if (count > 1) {
                  for (NocitAlgorithm.Peak peakobj2 : loci_peaks)
                  {
                    int allele2 = peakobj2.getAllele();
                    if (allele1 == allele2)
                    {
                      int index1 = loci_peaks.indexOf(peakobj1);
                      int index2 = loci_peaks.indexOf(peakobj2);
                      if (index1 != index2)
                      {
                        int h1 = peakobj1.getHeight();
                        int h2 = peakobj2.getHeight();
                        if (h1 >= h2)
                        {
                          if (!peakalleles_deleted.contains(Integer.valueOf(allele2)))
                          {
                            peaks_tobedeleted.add(peakobj2);
                            peakalleles_deleted.add(Integer.valueOf(allele2));
                          }
                        }
                        else if (!peakalleles_deleted.contains(Integer.valueOf(allele1)))
                        {
                          peaks_tobedeleted.add(peakobj1);
                          peakalleles_deleted.add(Integer.valueOf(allele1));
                        }
                      }
                    }
                  }
                }
              }
              NocitAlgorithm.Peak peakobj1;
              int allele1;
              for (NocitAlgorithm.Peak peakobj : loci_peaks) {
                if (!peaks_tobedeleted.contains(peakobj))
                {
                  loci_peaks_refresh.add(peakobj);
                  loci_alleles_refresh.add(Integer.valueOf(peakobj.getAllele()));
                }
              }
              for (Iterator i$ = trueAlleles.iterator(); i$.hasNext();)
              {
                int allele = ((Integer)i$.next()).intValue();
                
                true_Stutter_Alleles.add(Integer.valueOf(allele));
                int rev_allele = allele - 10;
                int fow_allele = allele + 10;
                if (loci_alleles_refresh.contains(Integer.valueOf(allele)))
                {
                  for (NocitAlgorithm.Peak peakobj : loci_peaks_refresh) {
                    if (peakobj.getAllele() == allele)
                    {
                      int height = peakobj.getHeight();
                      ((ArrayList)((HashMap)trueValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(height));
                      ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                    }
                  }
                  int parent_height;
                  if (loci_alleles_refresh.contains(Integer.valueOf(rev_allele)))
                  {
                    true_Stutter_Alleles.add(Integer.valueOf(rev_allele));
                    if ((!trueAlleles.contains(Integer.valueOf(rev_allele))) && (!trueAlleles.contains(Integer.valueOf(rev_allele - 10)))) {
                      for (NocitAlgorithm.Peak peakobj : loci_peaks_refresh) {
                        if (peakobj.getAllele() == allele)
                        {
                          parent_height = peakobj.getHeight();
                          for (NocitAlgorithm.Peak peakobj2 : loci_peaks_refresh)
                          {
                            int stut_allele = peakobj2.getAllele();
                            if (stut_allele == rev_allele)
                            {
                              int stut_height = peakobj2.getHeight();
                              double stut_ratio = stut_height / parent_height;
                              ((ArrayList)((HashMap)rstutterValues.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(stut_ratio));
                              ((ArrayList)((HashMap)rstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                            }
                          }
                        }
                      }
                    }
                  }
                  else
                  {
                    ((ArrayList)((HashMap)rstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                  }
                  // parent_height;
                  if (loci_alleles_refresh.contains(Integer.valueOf(fow_allele)))
                  {
                    true_Stutter_Alleles.add(Integer.valueOf(fow_allele));
                    if ((!trueAlleles.contains(Integer.valueOf(fow_allele))) && (!trueAlleles.contains(Integer.valueOf(fow_allele + 10)))) {
                      for (NocitAlgorithm.Peak peakobj : loci_peaks_refresh) {
                        if (peakobj.getAllele() == allele)
                        {
                          parent_height = peakobj.getHeight();
                          for (NocitAlgorithm.Peak peakobj2 : loci_peaks_refresh)
                          {
                            int stut_allele = peakobj2.getAllele();
                            if (stut_allele == fow_allele)
                            {
                              int stut_height = peakobj2.getHeight();
                              double stut_ratio = stut_height / parent_height;
                              ((ArrayList)((HashMap)fstutterValues.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(stut_ratio));
                              ((ArrayList)((HashMap)fstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                            }
                          }
                        }
                      }
                    }
                  }
                  else
                  {
                    ((ArrayList)((HashMap)fstutterDO.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                  }
                }
                else
                {
                  ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                }
              }
              Set<Integer> freq_alleles;
              if (this.freq_table.containsKey(locus))
              {
                freq_alleles = ((LinkedHashMap)this.freq_table.get(locus)).keySet();
                for (NocitAlgorithm.Peak obj : loci_peaks_refresh)
                {
                  int allele = obj.getAllele();
                  int height = obj.getHeight();
                  if ((!true_Stutter_Alleles.contains(Integer.valueOf(allele))) && (
                    (freq_alleles.contains(Integer.valueOf(allele))) || (freq_alleles.contains(Integer.valueOf(allele + 10))) || (freq_alleles.contains(Integer.valueOf(allele - 10))))) {
                    ((ArrayList)((HashMap)noiseValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(height));
                  }
                }
              }
              else
              {
                ((ArrayList)((HashMap)noiseValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
              }
            }
          }
          else
          {
            ArrayList<NocitAlgorithm.AMEL_Peak> amel_peaks = new ArrayList();
            ArrayList<String> amel_alleles = new ArrayList();
            ArrayList<NocitAlgorithm.AMEL_Peak> amel_peaks_refresh = new ArrayList();
            ArrayList<String> amel_alleles_refresh = new ArrayList();
            ArrayList<String> peakalleles_deleted = new ArrayList();
            ArrayList<NocitAlgorithm.AMEL_Peak> peaks_tobedeleted = new ArrayList();
            Set<String> trueAlleles = new HashSet();
            String trueallele1 = (String)line_refresh.get(2);
            String trueallele2 = (String)line_refresh.get(3);
            trueAlleles.add(trueallele1);
            trueAlleles.add(trueallele2);
            
            int j = 6;
            while (j < line_refresh.size())
            {
              if (!((String)line_refresh.get(j)).equals("OL"))
              {
                String allele = (String)line_refresh.get(j);
                int height = Integer.parseInt((String)line_refresh.get(j + 2));
                NocitAlgorithm.AMEL_Peak peakobject = new NocitAlgorithm.AMEL_Peak(allele, height);
                amel_peaks.add(peakobject);
                amel_alleles.add(peakobject.getAllele());
              }
              j += 3;
            }
            for (Iterator i$ = amel_peaks.iterator(); i$.hasNext();)
            {
                AMEL_Peak peakobj1 = (NocitAlgorithm.AMEL_Peak)i$.next();
                String allele1 = peakobj1.getAllele();
              int count = Collections.frequency(amel_alleles, allele1);
              if (count > 1) {
                for (NocitAlgorithm.AMEL_Peak peakobj2 : amel_peaks)
                {
                  String allele2 = peakobj2.getAllele();
                  if (allele1.contentEquals(allele2))
                  {
                    int index1 = amel_peaks.indexOf(peakobj1);
                    int index2 = amel_peaks.indexOf(peakobj2);
                    if (index1 != index2)
                    {
                      int h1 = peakobj1.getHeight();
                      int h2 = peakobj2.getHeight();
                      if (h1 >= h2)
                      {
                        if (!peakalleles_deleted.contains(allele2))
                        {
                          peaks_tobedeleted.add(peakobj2);
                          peakalleles_deleted.add(allele2);
                        }
                      }
                      else if (!peakalleles_deleted.contains(allele1))
                      {
                        peaks_tobedeleted.add(peakobj1);
                        peakalleles_deleted.add(allele1);
                      }
                    }
                  }
                }
              }
            }
            NocitAlgorithm.AMEL_Peak peakobj1;
            String allele1;
            for (NocitAlgorithm.AMEL_Peak peakobj : amel_peaks) {
              if (!peaks_tobedeleted.contains(peakobj))
              {
                amel_peaks_refresh.add(peakobj);
                amel_alleles_refresh.add(peakobj.getAllele());
              }
            }
            if (!trueallele1.contentEquals(trueallele2)) {
              for (String allele : trueAlleles) {
                if (amel_alleles_refresh.contains(allele)) {
                  for (NocitAlgorithm.AMEL_Peak peakobj : amel_peaks_refresh) {
                    if (allele.contentEquals(peakobj.getAllele()))
                    {
                      int height = peakobj.getHeight();
                      ((ArrayList)((HashMap)trueValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(height));
                      ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(1));
                    }
                  }
                } else {
                  ((ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(0));
                }
              }
            } else if ((amel_alleles_refresh.contains("Y")) && 
              (!trueAlleles.contains("Y"))) {
              for (NocitAlgorithm.AMEL_Peak obj : amel_peaks_refresh) {
                if (obj.getAllele().contentEquals("Y")) {
                  ((ArrayList)((HashMap)noiseValues.get(Double.valueOf(mass))).get(locus)).add(Integer.valueOf(obj.getHeight()));
                }
              }
            }
          }
        }
      }
      catch (IOException e)
      {
        System.out.println(e.getMessage());
      }
      for (Iterator i$ = this.masses.iterator(); i$.hasNext();)
      {
          double mass = ((Double)i$.next()).doubleValue();
        for (String locus : this.calibLoci)
        {
          ArrayList<Integer> dovalues = (ArrayList)((HashMap)dropout.get(Double.valueOf(mass))).get(locus);
          int do_count = Collections.frequency(dovalues, Integer.valueOf(0));
          double do_obs = dovalues.size();
          double final_do = do_count / do_obs;
          ((HashMap)this.dropoutCalibData.get(Double.valueOf(mass))).put(locus, Double.valueOf(final_do));
          
          DescriptiveStatistics trueStats = new DescriptiveStatistics();
          for (Iterator ii$ = ((ArrayList)((HashMap)trueValues.get(Double.valueOf(mass))).get(locus)).iterator(); ii$.hasNext();)
          {
            int val = ((Integer)ii$.next()).intValue();
            trueStats.addValue(val);
          }
          double trueMean = trueStats.getMean();
          double trueStddev = trueStats.getStandardDeviation();
          ((ArrayList)((HashMap)this.trueCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(trueMean));
          ((ArrayList)((HashMap)this.trueCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(trueStddev));
          
          DescriptiveStatistics noiseStats = new DescriptiveStatistics();
          for (Iterator ii$ = ((ArrayList)((HashMap)noiseValues.get(Double.valueOf(mass))).get(locus)).iterator(); ii$.hasNext();)
          {
            int val = ((Integer)ii$.next()).intValue();
            noiseStats.addValue(val);
          }
          double noiseMean = noiseStats.getMean();
          double noiseStddev = noiseStats.getStandardDeviation();
          ((ArrayList)((HashMap)this.noiseCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(noiseMean));
          ((ArrayList)((HashMap)this.noiseCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(noiseStddev));
          if (!locus.contentEquals("AMEL"))
          {
            ArrayList<Integer> rstutdovalues = (ArrayList)((HashMap)rstutterDO.get(Double.valueOf(mass))).get(locus);
            int rstutdo_count = Collections.frequency(rstutdovalues, Integer.valueOf(0));
            double rstut_obs = rstutdovalues.size();
            double rstut_do = rstutdo_count / rstut_obs;
            ((HashMap)this.rstutterDOCalibData.get(Double.valueOf(mass))).put(locus, Double.valueOf(rstut_do));
            
            ArrayList<Integer> fstutdovalues = (ArrayList)((HashMap)fstutterDO.get(Double.valueOf(mass))).get(locus);
            int fstutdo_count = Collections.frequency(fstutdovalues, Integer.valueOf(0));
            double fstut_obs = fstutdovalues.size();
            double fstut_do = fstutdo_count / fstut_obs;
            ((HashMap)this.fstutterDOCalibData.get(Double.valueOf(mass))).put(locus, Double.valueOf(fstut_do));
            
            DescriptiveStatistics rstutterStats = new DescriptiveStatistics();
            for (Iterator ii$ = ((ArrayList)((HashMap)rstutterValues.get(Double.valueOf(mass))).get(locus)).iterator(); ii$.hasNext();)
            {
              double val = ((Double)ii$.next()).doubleValue();
              rstutterStats.addValue(val);
            }
            double rstutterMean = rstutterStats.getMean();
            double rstutterStddev = rstutterStats.getStandardDeviation();
            ((ArrayList)((HashMap)this.rstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(rstutterMean));
            ((ArrayList)((HashMap)this.rstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(rstutterStddev));
            
            DescriptiveStatistics fstutterStats = new DescriptiveStatistics();
            for (Iterator ii$ = ((ArrayList)((HashMap)fstutterValues.get(Double.valueOf(mass))).get(locus)).iterator(); ii$.hasNext();)
            {
              double val = ((Double)ii$.next()).doubleValue();
              fstutterStats.addValue(val);
            }
            double fstutterMean = fstutterStats.getMean();
            double fstutterStddev = fstutterStats.getStandardDeviation();
            ((ArrayList)((HashMap)this.fstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(fstutterMean));
            ((ArrayList)((HashMap)this.fstutterCalibData.get(Double.valueOf(mass))).get(locus)).add(Double.valueOf(fstutterStddev));
          }
        }
      }
      double mass;
    }
    
    public HashMap<Double, HashMap<String, Double>> getDOCalibData()
    {
      return this.dropoutCalibData;
    }
    
    public HashMap<Double, HashMap<String, Double>> getfstutDOCalibData()
    {
      return this.fstutterDOCalibData;
    }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getfstutterCalibData()
    {
      return this.fstutterCalibData;
    }
    
    public HashSet<String> getLoci()
    {
      return this.calibLoci;
    }
    
    public HashSet<Double> getMasses()
    {
      return this.masses;
    }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getNoiseCalibData()
    {
      return this.noiseCalibData;
    }
    
    public HashMap<Double, HashMap<String, Double>> getrstutDOCalibData()
    {
      return this.rstutterDOCalibData;
    }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getrstutterCalibData()
    {
      return this.rstutterCalibData;
    }
    
    public HashMap<Double, HashMap<String, ArrayList<Double>>> getTrueCalibData()
    {
      return this.trueCalibData;
    }
  }
  
  private static class LinFunction
    implements ParametricRealFunction
  {

        private LinFunction(Object object) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    public double[] gradient(double x, double[] parameters)
    {
      double a_grad = x;
      double b_grad = 1.0D;
      double[] grad = { a_grad, b_grad };
      return grad;
    }
    
    public double value(double x, double[] parameters)
    {
      double a = parameters[0];
      double b = parameters[1];
      return a * x + b;
    }
  }
  
  private static class ExpFunction
    implements ParametricRealFunction
  {

        private ExpFunction(Object object) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    public double[] gradient(double x, double[] parameters)
    {
      double a = parameters[0];
      double b = parameters[1];
      double a_grad = Math.exp(b * x);
      double b_grad = a * x * Math.exp(b * x);
      double[] grad = { a_grad, b_grad };
      return grad;
    }
    
    public double value(double x, double[] parameters)
    {
      double a = parameters[0];
      double b = parameters[1];
      return a * Math.exp(b * x);
    }
  }
  
  private static class TwoExpFunction
    implements ParametricRealFunction
  {

        private TwoExpFunction(Object object) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    public double[] gradient(double x, double[] parameters)
    {
      double a = parameters[0];
      double b = parameters[1];
      double a_grad = Math.exp(b * x);
      double b_grad = a * x * Math.exp(b * x);
      double c_grad = 1.0D;
      double[] grad = { a_grad, b_grad, c_grad };
      return grad;
    }
    
    public double value(double x, double[] parameters)
    {
      return parameters[0] * Math.exp(parameters[1] * x) + parameters[2];
    }
  }
  
  private static class PosTwoExpFunction
    implements ParametricRealFunction
  {

        private PosTwoExpFunction(Object object) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    public double[] gradient(double x, double[] parameters)
    {
      double a = parameters[0];
      double b = parameters[1];
      double a_grad = Math.exp(b * x);
      double b_grad = a * x * Math.exp(b * x);
      double c_grad = 1.0D;
      if (parameters[2] < 0.0D) {
        c_grad = 0.0D;
      }
      double[] grad = { a_grad, b_grad, c_grad };
      return grad;
    }
    
    public double value(double x, double[] parameters)
    {
      return parameters[0] * Math.exp(parameters[1] * x) + Math.max(0.0D, parameters[2]);
    }
  }
  
  private static class FreqTable
  {
    private String path;
    private ArrayList<String> loci_list;
    private LinkedHashMap<String, LinkedHashMap<Integer, Double>> freq_table;
    
    FreqTable(String file_path)
    {
      this.path = file_path;
      this.loci_list = new ArrayList();
      this.freq_table = new LinkedHashMap();
      try
      {
        NocitAlgorithm.OpenAndReadFile freqfile = new NocitAlgorithm.OpenAndReadFile(this.path);
        String[] fileLines = freqfile.FileContents();
        for (int i = 1; i < fileLines.length; i++)
        {
          String line = fileLines[i];
          String[] parts = line.split(",");
          String locus = parts[0];
          if (!this.loci_list.contains(locus)) {
            this.loci_list.add(locus);
          }
        }
        for (String locus : this.loci_list) {
          this.freq_table.put(locus, new LinkedHashMap());
        }
        for (int i = 1; i < fileLines.length; i++)
        {
          String line = fileLines[i];
          String[] parts = line.split(",");
          String locus = parts[0];
          double a = Double.parseDouble(parts[1]);
          int allele = (int)Math.round(a * 10.0D);
          double frequency = Double.parseDouble(parts[2]);
          ((LinkedHashMap)this.freq_table.get(locus)).put(Integer.valueOf(allele), Double.valueOf(frequency));
        }
      }
      catch (IOException e)
      {
        System.out.println(e.getMessage());
      }
    }
    
    public ArrayList<String> getFreqLociList()
    {
      return this.loci_list;
    }
    
    public LinkedHashMap<String, LinkedHashMap<Integer, Double>> getFreqTable()
    {
      return this.freq_table;
    }
  }
  
  private static LinkedHashMap<String, LinkedHashMap<Integer, Integer>> intervals(LinkedHashMap<String, LinkedHashMap<Integer, Double>> freqdict, ArrayList<String> locilist)
  {
    LinkedHashMap<String, LinkedHashMap<Integer, Double>> freq_dict = freqdict;
    ArrayList<String> loci_list = locilist;
    
    LinkedHashMap<String, LinkedHashMap<Integer, Integer>> intervals_map = new LinkedHashMap();
    LinkedHashMap<String, LinkedHashMap<Integer, int[]>> endpoints_map = new LinkedHashMap();
    for (int i = 0; i < loci_list.size(); i++)
    {
      intervals_map.put(loci_list.get(i), new LinkedHashMap());
      endpoints_map.put(loci_list.get(i), new LinkedHashMap());
    }
    for (Iterator i$ = freq_dict.keySet().iterator(); i$.hasNext();)
    {
        String locus = (String)i$.next();
      int[] keys_array = new int[((LinkedHashMap)freq_dict.get(locus)).size()];
      double[] values_array = new double[((LinkedHashMap)freq_dict.get(locus)).size()];
      
      int counter = 0;
      for (Iterator ii$ = ((LinkedHashMap)freq_dict.get(locus)).keySet().iterator(); ii$.hasNext();)
      {
        int allele = ((Integer)ii$.next()).intValue();
        keys_array[counter] = allele;
        values_array[counter] = ((Double)((LinkedHashMap)freq_dict.get(locus)).get(Integer.valueOf(allele))).doubleValue();
        counter++;
      }
      int count = 0;
      while (count < keys_array.length)
      {
        if (count == 0)
        {
          ((LinkedHashMap)endpoints_map.get(locus)).put(Integer.valueOf(keys_array[count]), new int[] { 0, (int)Math.round(10000.0D * values_array[count]) - 1 });
        }
        else
        {
          int init_value = ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(Integer.valueOf(keys_array[(count - 1)])))[1] + 1;
          ((LinkedHashMap)endpoints_map.get(locus)).put(Integer.valueOf(keys_array[count]), new int[] { init_value, init_value + (int)Math.round(10000.0D * values_array[count]) - 1 });
        }
        count++;
      }
      for (i$ = ((LinkedHashMap)endpoints_map.get(locus)).keySet().iterator(); i$.hasNext();)
      {
        int allele = ((Integer)i$.next()).intValue();
        int i = ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(Integer.valueOf(allele)))[0];
        while (i <= ((int[])((LinkedHashMap)endpoints_map.get(locus)).get(Integer.valueOf(allele)))[1])
        {
          ((LinkedHashMap)intervals_map.get(locus)).put(Integer.valueOf(i), Integer.valueOf(allele));
          i++;
        }
      }
    }
    String locus;
    Iterator i$;
    return intervals_map;
  }
  
  private static class OpenAndReadFile
  {
    private String path;
    
    OpenAndReadFile(String file_path)
    {
      this.path = file_path;
    }
    
    public String[] FileContents()
      throws IOException
    {
      FileReader fr = new FileReader(this.path);
      
      BufferedReader textReader = new BufferedReader(fr);Throwable localThrowable2 = null;
      String[] textData;
      try
      {
        int numberOfLines = readLines();
        textData = new String[numberOfLines];
        for (int i = 0; i < numberOfLines; i++) {
          textData[i] = textReader.readLine();
        }
      }
      catch (Throwable localThrowable1)
      {
        localThrowable2 = localThrowable1;throw localThrowable1;
      }
      finally
      {
        if (textReader != null) {
          if (localThrowable2 != null) {
            try
            {
              textReader.close();
            }
            catch (Throwable x2)
            {
              localThrowable2.addSuppressed(x2);
            }
          } else {
            textReader.close();
          }
        }
      }
      return textData;
    }
    
    public int readLines()
      throws IOException
    {
      FileReader file_to_read = new FileReader(this.path);
      
      BufferedReader bf = new BufferedReader(file_to_read);Throwable localThrowable2 = null;
      int numberOfLines;
      try
      {
        numberOfLines = 0;
        while (bf.readLine() != null) {
          numberOfLines++;
        }
      }
      catch (Throwable localThrowable1)
      {
        localThrowable2 = localThrowable1;throw localThrowable1;
      }
      finally
      {
        if (bf != null) {
          if (localThrowable2 != null) {
            try
            {
              bf.close();
            }
            catch (Throwable x2)
            {
              localThrowable2.addSuppressed(x2);
            }
          } else {
            bf.close();
          }
        }
      }
      return numberOfLines;
    }
  }
  
  private static class parseSampleFile
  {
    private String sample_file_path;
    private ConcurrentHashMap<String, ConcurrentHashMap<Integer, NocitAlgorithm.Peak>> loci_peaks;
    private ConcurrentHashMap<String, ConcurrentHashMap<String, NocitAlgorithm.AMEL_Peak>> AMEL_peaks;
    private HashMap<String, ArrayList<Integer>> loci_peakalleles;
    private HashMap<String, ArrayList<String>> AMEL_peakalleles;
    private ArrayList<String> sample_loci;
    
    parseSampleFile(String samplefilepath)
    {
      this.sample_file_path = samplefilepath;
      this.loci_peaks = new ConcurrentHashMap();
      this.AMEL_peaks = new ConcurrentHashMap();
      this.loci_peakalleles = new HashMap();
      this.AMEL_peakalleles = new HashMap();
      this.sample_loci = new ArrayList();
      try
      {
        NocitAlgorithm.OpenAndReadFile samplefile = new NocitAlgorithm.OpenAndReadFile(this.sample_file_path);
        String[] samplefilelines = samplefile.FileContents();
        for (int linecount = 1; linecount < samplefilelines.length; linecount++)
        {
          String line = samplefilelines[linecount];
          String[] line_parts = line.split(",");
          List<String> line_refresh = new ArrayList();
          for (String element : line_parts) {
            if (element != null) {
              line_refresh.add(element);
            }
          }
          String locus = (String)line_refresh.get(1);
          this.sample_loci.add(locus);
          if (!locus.equals("AMEL"))
          {
            this.loci_peaks.put(locus, new ConcurrentHashMap());
            ArrayList<Integer> peakalleles_deleted = new ArrayList();
            ArrayList<NocitAlgorithm.Peak> peaks_tobedeleted = new ArrayList();
            ArrayList<NocitAlgorithm.Peak> peak_array = new ArrayList();
            ArrayList<Integer> peak_alleles = new ArrayList();
            ArrayList<Integer> peak_alleles_refresh = new ArrayList();
            int i = 3;
            while (i < line_refresh.size())
            {
              if (!((String)line_refresh.get(i)).equals("OL"))
              {
                double a = Double.parseDouble((String)line_refresh.get(i));
                int allele = (int)Math.round(a * 10.0D);
                int height = Integer.parseInt((String)line_refresh.get(i + 2));
                NocitAlgorithm.Peak peakobject = new NocitAlgorithm.Peak(allele, height);
                peak_array.add(peakobject);
                peak_alleles.add(Integer.valueOf(peakobject.getAllele()));
              }
              i += 3;
            }
            for (Iterator i$ = peak_array.iterator(); i$.hasNext();)
            {
                Peak peakobj1 = (NocitAlgorithm.Peak)i$.next();
                int allele1 = peakobj1.getAllele();
              int count = Collections.frequency(peak_alleles, Integer.valueOf(allele1));
              if (count > 1) {
                for (NocitAlgorithm.Peak peakobj2 : peak_array)
                {
                  int allele2 = peakobj2.getAllele();
                  if (allele1 == allele2)
                  {
                    int index1 = peak_array.indexOf(peakobj1);
                    int index2 = peak_array.indexOf(peakobj2);
                    if (index1 != index2)
                    {
                      int h1 = peakobj1.getHeight();
                      int h2 = peakobj2.getHeight();
                      if (h1 >= h2)
                      {
                        if (!peakalleles_deleted.contains(Integer.valueOf(allele2)))
                        {
                          peaks_tobedeleted.add(peakobj2);
                          peakalleles_deleted.add(Integer.valueOf(allele2));
                        }
                      }
                      else if (!peakalleles_deleted.contains(Integer.valueOf(allele1)))
                      {
                        peaks_tobedeleted.add(peakobj1);
                        peakalleles_deleted.add(Integer.valueOf(allele1));
                      }
                    }
                  }
                }
              }
            }
            NocitAlgorithm.Peak peakobj1;
            int allele1;
            for (NocitAlgorithm.Peak peakobj : peak_array) {
              if (!peaks_tobedeleted.contains(peakobj))
              {
                peak_alleles_refresh.add(Integer.valueOf(peakobj.getAllele()));
                ((ConcurrentHashMap)this.loci_peaks.get(locus)).put(Integer.valueOf(peakobj.getAllele()), peakobj);
              }
            }
            this.loci_peakalleles.put(locus, peak_alleles_refresh);
          }
          else
          {
            this.AMEL_peaks.put(locus, new ConcurrentHashMap());
            ArrayList<String> peakalleles_deleted = new ArrayList();
            ArrayList<NocitAlgorithm.AMEL_Peak> peaks_tobedeleted = new ArrayList();
            ArrayList<NocitAlgorithm.AMEL_Peak> peak_array = new ArrayList();
            ArrayList<String> peak_alleles = new ArrayList();
            ArrayList<String> peak_alleles_refresh = new ArrayList();
            int i = 3;
            while (i < line_refresh.size())
            {
              if (!((String)line_refresh.get(i)).equals("OL"))
              {
                String allele = (String)line_refresh.get(i);
                int height = Integer.parseInt((String)line_refresh.get(i + 2));
                NocitAlgorithm.AMEL_Peak peakobject = new NocitAlgorithm.AMEL_Peak(allele, height);
                peak_array.add(peakobject);
                peak_alleles.add(peakobject.getAllele());
              }
              i += 3;
            }
            for (Iterator i$ = peak_array.iterator(); i$.hasNext();)
            {
                AMEL_Peak peakobj1 = (NocitAlgorithm.AMEL_Peak)i$.next();
                String allele1 = peakobj1.getAllele();
              int count = Collections.frequency(peak_alleles, allele1);
              if (count > 1) {
                for (NocitAlgorithm.AMEL_Peak peakobj2 : peak_array)
                {
                  String allele2 = peakobj2.getAllele();
                  if (allele1.contentEquals(allele2))
                  {
                    int index1 = peak_array.indexOf(peakobj1);
                    int index2 = peak_array.indexOf(peakobj2);
                    if (index1 != index2)
                    {
                      int h1 = peakobj1.getHeight();
                      int h2 = peakobj2.getHeight();
                      if (h1 >= h2)
                      {
                        if (!peakalleles_deleted.contains(allele2))
                        {
                          peaks_tobedeleted.add(peakobj2);
                          peakalleles_deleted.add(allele2);
                        }
                      }
                      else if (!peakalleles_deleted.contains(allele1))
                      {
                        peaks_tobedeleted.add(peakobj1);
                        peakalleles_deleted.add(allele1);
                      }
                    }
                  }
                }
              }
            }
            NocitAlgorithm.AMEL_Peak peakobj1;
            String allele1;
            for (NocitAlgorithm.AMEL_Peak peakobj : peak_array) {
              if (!peaks_tobedeleted.contains(peakobj))
              {
                peak_alleles_refresh.add(peakobj.getAllele());
                ((ConcurrentHashMap)this.AMEL_peaks.get(locus)).put(peakobj.getAllele(), peakobj);
              }
            }
            this.AMEL_peakalleles.put(locus, peak_alleles_refresh);
          }
        }
      }
      catch (IOException e)
      {
        System.out.println(e.getMessage());
      }
    }
    
    public HashMap<String, ArrayList<String>> getAMELAlleles()
    {
      return this.AMEL_peakalleles;
    }
    
    public ConcurrentHashMap<String, ConcurrentHashMap<String, NocitAlgorithm.AMEL_Peak>> getAMELPeaks()
    {
      return this.AMEL_peaks;
    }
    
    public HashMap<String, ArrayList<Integer>> getLociAlleles()
    {
      return this.loci_peakalleles;
    }
    
    public ConcurrentHashMap<String, ConcurrentHashMap<Integer, NocitAlgorithm.Peak>> getLociPeaks()
    {
      return this.loci_peaks;
    }
    
    public ArrayList<String> getSampleLoci()
    {
      return this.sample_loci;
    }
  }
  
  private static double calcLocusPeakHeightsProb(ConcurrentHashMap<Integer, Peak> allpeaks, HashMap<Integer, Double> mus, HashMap<Integer, Double> sigmasquareds)
  {
    double first_term = 1.0D;
    double sum = 0.0D;
    for (Peak peakobj : allpeaks.values())
    {
      first_term *= 1.0D / Math.sqrt(6.283185307179586D * ((Double)sigmasquareds.get(Integer.valueOf(peakobj.getAllele()))).doubleValue());
      sum += (peakobj.getHeight() - ((Double)mus.get(Integer.valueOf(peakobj.getAllele()))).doubleValue()) * (peakobj.getHeight() - ((Double)mus.get(Integer.valueOf(peakobj.getAllele()))).doubleValue()) / ((Double)sigmasquareds.get(Integer.valueOf(peakobj.getAllele()))).doubleValue();
    }
    return first_term * Math.exp(-0.5D * sum);
  }
  
  private static double calcAMELPeakHeightsProb(ConcurrentHashMap<String, AMEL_Peak> allpeaks, HashMap<String, Double> mus, HashMap<String, Double> sigmasquareds)
  {
    double first_term = 1.0D;
    double sum = 0.0D;
    for (AMEL_Peak peakobj : allpeaks.values())
    {
      first_term *= 1.0D / Math.sqrt(6.283185307179586D * ((Double)sigmasquareds.get(peakobj.getAllele())).doubleValue());
      sum += (peakobj.getHeight() - ((Double)mus.get(peakobj.getAllele())).doubleValue()) * (peakobj.getHeight() - ((Double)mus.get(peakobj.getAllele())).doubleValue()) / ((Double)sigmasquareds.get(peakobj.getAllele())).doubleValue();
    }
    return first_term * Math.exp(-0.5D * sum);
  }
  
  private static double[] generateRandomTotal(int numb)
  {
    int number = numb;
    


    double[] sorted_array = new double[number];
    Double[] num_array = new Double[number - 1];
    
    int count = 1;
    while (count <= number - 1)
    {
      double num = ThreadLocalRandom.current().nextDouble(1.0D);
      num_array[(count - 1)] = Double.valueOf(num);
      count++;
    }
    Arrays.sort(num_array);
    ArrayList<Double> num_array1 = new ArrayList(Arrays.asList(num_array));
    ArrayList<Double> num_array2 = new ArrayList(Arrays.asList(num_array));
    num_array2.add(Double.valueOf(1.0D));
    num_array1.add(0, Double.valueOf(0.0D));
    for (int i = 0; i <= number - 1; i++)
    {
      double diff = ((Double)num_array2.get(i)).doubleValue() - ((Double)num_array1.get(i)).doubleValue();
      sorted_array[i] = diff;
    }
    return sorted_array;
  }
  
  private static class Sum_threads_amel
    implements Callable<NocitAlgorithm.Callable_amel_object>
  {
    private int count_num;
    private int num_of_ppl;
    private String locus_name;
    private double max_val;
    private Set<String> max_alls = new HashSet();
    private double sum;
    
    Sum_threads_amel(int count, int numofppl, String locusname)
    {
      this.count_num = count;
      this.num_of_ppl = numofppl;
      this.locus_name = locusname;
      this.max_val = 0.0D;
      this.sum = 0.0D;
    }
    
    public NocitAlgorithm.Callable_amel_object call()
    {
      HashMap<Integer, ArrayList<String>> genotypes = new HashMap();
      HashMap<String, Double> weights = new HashMap();
      HashMap<String, Double> means = new HashMap();
      HashMap<String, Double> variances = new HashMap();
      Set<String> true_alleles = new HashSet();
      Set<String> selected_true_alleles = new HashSet();
      











      double[] values = NocitAlgorithm.calcSlopeValue(this.locus_name, NocitAlgorithm.DNA_Mass, NocitAlgorithm.Noise_Mean_Slope, NocitAlgorithm.Noise_Stddev_Slope);
      double noise_mu = values[0];
      double noise_sigmasquared = values[1] * values[1];
      for (int iteration = 1; iteration <= this.count_num; iteration++)
      {
        ConcurrentHashMap<String, NocitAlgorithm.AMEL_Peak> allPeaks = new ConcurrentHashMap((Map)NocitAlgorithm.AMEL_Peaks.get(this.locus_name));
        double[] g;
       // double[] g;
        if (this.num_of_ppl == 1) {
          g = new double[] { 1.0D };
        } else {
          g = NocitAlgorithm.generateRandomTotal(this.num_of_ppl);
        }
        for (int contributor = 1; contributor <= this.num_of_ppl; contributor++)
        {
          genotypes.put(Integer.valueOf(contributor), new ArrayList(2));
          String sex = NocitAlgorithm.Sexes[ThreadLocalRandom.current().nextInt(2)];
          ((ArrayList)genotypes.get(Integer.valueOf(contributor))).add(((String[])NocitAlgorithm.Sexes_Genotype.get(sex))[0]);
          ((ArrayList)genotypes.get(Integer.valueOf(contributor))).add(((String[])NocitAlgorithm.Sexes_Genotype.get(sex))[1]);
          for (Object allele : (ArrayList)genotypes.get(Integer.valueOf(contributor)))
          {
            NocitAlgorithm.AMEL_Peak peakobj = (NocitAlgorithm.AMEL_Peak)allPeaks.get(allele);
            if (peakobj == null)
            {
              NocitAlgorithm.AMEL_Peak p = new NocitAlgorithm.AMEL_Peak((String) allele, 0);
              allPeaks.put((String) allele, p);
            }
            selected_true_alleles.add((String) allele);
            
            double cont_mass = g[(contributor - 1)] * NocitAlgorithm.DNA_Mass;
            if (ThreadLocalRandom.current().nextDouble(1.0D) > NocitAlgorithm.calcExpValue(this.locus_name, NocitAlgorithm.Locus_DO, cont_mass))
            {
              true_alleles.add((String) allele);
              if (weights.containsKey(allele)) {
                weights.put((String) allele, Double.valueOf(((Double)weights.get(allele)).doubleValue() + cont_mass));
              } else {
                weights.put((String) allele, Double.valueOf(cont_mass));
              }
            }
          }
        }
        for (String allele_name : true_alleles)
        {
          values = NocitAlgorithm.calcSlopeValue(this.locus_name, ((Double)weights.get(allele_name)).doubleValue(), NocitAlgorithm.True_Mean_Slope, NocitAlgorithm.True_Stddev_Slope);
          double true_mu = values[0];
          double true_sigmasquared = values[1] * values[1];
          means.put(allele_name, Double.valueOf(true_mu));
          variances.put(allele_name, Double.valueOf(true_sigmasquared));
        }
        for (NocitAlgorithm.AMEL_Peak peakobj : allPeaks.values()) {
          if (!means.containsKey(peakobj.getAllele()))
          {
            means.put(peakobj.getAllele(), Double.valueOf(noise_mu));
            variances.put(peakobj.getAllele(), Double.valueOf(noise_sigmasquared));
          }
        }
        double val_y = NocitAlgorithm.calcAMELPeakHeightsProb(allPeaks, means, variances);
        this.sum += val_y;
        if (val_y > this.max_val)
        {
          this.max_val = val_y;
          this.max_alls.clear();
          for (String allele_name : selected_true_alleles) {
            this.max_alls.add(allele_name);
          }
        }
        genotypes.clear();
        weights.clear();
        means.clear();
        variances.clear();
        true_alleles.clear();
        allPeaks.clear();
        selected_true_alleles.clear();
      }
      NocitAlgorithm.Callable_amel_object clobject = new NocitAlgorithm.Callable_amel_object(this.sum, this.max_val, this.max_alls);
      return clobject;
    }
  }
  
  private static class Sum_threads_stutterloci
    implements Callable<NocitAlgorithm.Callable_loci_object>
  {
    private int count_num;
    private int num_of_ppl;
    private String locus_name;
    private double sum;
    private double max_val;
    private Set<Integer> max_alls = new HashSet();
    private HashSet<String> rstut_loci;
    private HashSet<String> fstut_loci;
    
    Sum_threads_stutterloci(int count, int numofppl, String locusname, HashSet<String> rstutloci, HashSet<String> fstutloci)
    {
      this.count_num = count;
      this.num_of_ppl = numofppl;
      this.locus_name = locusname;
      this.sum = 0.0D;
      this.max_val = 0.0D;
      this.rstut_loci = rstutloci;
      this.fstut_loci = fstutloci;
    }
    
    public NocitAlgorithm.Callable_loci_object call()
    {
      Integer final_value = (Integer)NocitAlgorithm.Final_Values.get(this.locus_name);
      ArrayList<Integer> loc_alleles = (ArrayList)NocitAlgorithm.Loci_Alleles.get(this.locus_name);
      
      HashMap<Integer, ArrayList<Integer>> genotypes = new HashMap();
      HashMap<Integer, Double> weights = new HashMap();
      HashMap<Integer, Double> means = new HashMap();
      HashMap<Integer, Double> variances = new HashMap();
      Set<Integer> selected_true_alleles = new HashSet();
      Set<Integer> true_alleles = new HashSet();
      




















      double[] values = NocitAlgorithm.calcSlopeValue(this.locus_name, NocitAlgorithm.DNA_Mass, NocitAlgorithm.Noise_Mean_Slope, NocitAlgorithm.Noise_Stddev_Slope);
      double noise_mu = values[0];
      double noise_sigmasquared = values[1] * values[1];
      for (int iteration = 1; iteration <= this.count_num; iteration++)
      {
        ConcurrentHashMap<Integer, NocitAlgorithm.Peak> allPeaks = new ConcurrentHashMap((Map)NocitAlgorithm.Loci_Peaks.get(this.locus_name));
        double[] g;
       // double[] g;
        if (this.num_of_ppl == 1) {
          g = new double[] { 1.0D };
        } else {
          g = NocitAlgorithm.generateRandomTotal(this.num_of_ppl);
        }
        for (int contributor = 1; contributor <= this.num_of_ppl; contributor++)
        {
          genotypes.put(Integer.valueOf(contributor), new ArrayList());
          for (int j = 1; j <= 2; j++)
          {
            int r = (int)Math.round(ThreadLocalRandom.current().nextDouble(1.0D) * final_value.intValue());
            int allele = ((Integer)((LinkedHashMap)NocitAlgorithm.Intervals_Map.get(this.locus_name)).get(Integer.valueOf(r))).intValue();
            ((ArrayList)genotypes.get(Integer.valueOf(contributor))).add(Integer.valueOf(allele));
            
            selected_true_alleles.add(Integer.valueOf(allele));
            
            NocitAlgorithm.Peak peakobj = (NocitAlgorithm.Peak)allPeaks.get(Integer.valueOf(allele));
            if (peakobj == null)
            {
              NocitAlgorithm.Peak p = new NocitAlgorithm.Peak(allele, 0);
              allPeaks.put(Integer.valueOf(allele), p);
            }
            double cont_mass = g[(contributor - 1)] * NocitAlgorithm.DNA_Mass;
            if (ThreadLocalRandom.current().nextDouble(1.0D) > NocitAlgorithm.calcExpValue(this.locus_name, NocitAlgorithm.Locus_DO, cont_mass))
            {
              true_alleles.add(Integer.valueOf(allele));
              if (weights.containsKey(Integer.valueOf(allele))) {
                weights.put(Integer.valueOf(allele), Double.valueOf(((Double)weights.get(Integer.valueOf(allele))).doubleValue() + cont_mass));
              } else {
                weights.put(Integer.valueOf(allele), Double.valueOf(cont_mass));
              }
            }
          }
        }
        for (Iterator i$ = true_alleles.iterator(); i$.hasNext();)
        {
          int allele_name = ((Integer)i$.next()).intValue();
          int height = ((NocitAlgorithm.Peak)allPeaks.get(Integer.valueOf(allele_name))).getHeight();
          values = NocitAlgorithm.calcSlopeValue(this.locus_name, ((Double)weights.get(Integer.valueOf(allele_name))).doubleValue(), NocitAlgorithm.True_Mean_Slope, NocitAlgorithm.True_Stddev_Slope);
          double true_mu = values[0];
          double true_sigmasquared = values[1] * values[1];
          means.put(Integer.valueOf(allele_name), Double.valueOf(true_mu));
          variances.put(Integer.valueOf(allele_name), Double.valueOf(true_sigmasquared));
          if (loc_alleles.contains(Integer.valueOf(allele_name)))
          {
            double parentWeight = ((Double)weights.get(Integer.valueOf(allele_name))).doubleValue();
            if (this.rstut_loci.contains(this.locus_name)) {
              if (ThreadLocalRandom.current().nextDouble(1.0D) > NocitAlgorithm.calcExpValue(this.locus_name, NocitAlgorithm.R_Stut_DO, parentWeight))
              {
                double rstut_mu = NocitAlgorithm.calcTwoExpValue(this.locus_name, NocitAlgorithm.R_Stutter_Mean, parentWeight) * height;
                double rstut_sigma = NocitAlgorithm.calcTwoExpValue(this.locus_name, NocitAlgorithm.R_Stutter_Stddev, parentWeight) * height;
                int revStutterAllele = allele_name - 10;
                NocitAlgorithm.Peak revStutterPeak = (NocitAlgorithm.Peak)allPeaks.get(Integer.valueOf(revStutterAllele));
                if (revStutterPeak == null)
                {
                  NocitAlgorithm.Peak p = new NocitAlgorithm.Peak(revStutterAllele, 0);
                  allPeaks.put(Integer.valueOf(revStutterAllele), p);
                }
                if (means.containsKey(Integer.valueOf(revStutterAllele)))
                {
                  means.put(Integer.valueOf(revStutterAllele), Double.valueOf(((Double)means.get(Integer.valueOf(revStutterAllele))).doubleValue() + rstut_mu));
                  variances.put(Integer.valueOf(revStutterAllele), Double.valueOf(((Double)variances.get(Integer.valueOf(revStutterAllele))).doubleValue() + rstut_sigma * rstut_sigma));
                }
                else
                {
                  means.put(Integer.valueOf(revStutterAllele), Double.valueOf(rstut_mu));
                  variances.put(Integer.valueOf(revStutterAllele), Double.valueOf(rstut_sigma * rstut_sigma));
                }
              }
            }
            if ((this.fstut_loci.contains(this.locus_name)) && 
              (ThreadLocalRandom.current().nextDouble(1.0D) > NocitAlgorithm.calcExpValue(this.locus_name, NocitAlgorithm.F_Stut_DO, parentWeight)))
            {
              double fstut_mu = NocitAlgorithm.calcTwoExpValue(this.locus_name, NocitAlgorithm.F_Stutter_Mean, parentWeight) * height;
              double fstut_sigma = NocitAlgorithm.calcTwoExpValue(this.locus_name, NocitAlgorithm.F_Stutter_Stddev, parentWeight) * height;
              int fowStutterAllele = allele_name + 10;
              NocitAlgorithm.Peak fowStutterPeak = (NocitAlgorithm.Peak)allPeaks.get(Integer.valueOf(fowStutterAllele));
              if (fowStutterPeak == null)
              {
                NocitAlgorithm.Peak p = new NocitAlgorithm.Peak(fowStutterAllele, 0);
                allPeaks.put(Integer.valueOf(fowStutterAllele), p);
              }
              if (means.containsKey(Integer.valueOf(fowStutterAllele)))
              {
                means.put(Integer.valueOf(fowStutterAllele), Double.valueOf(((Double)means.get(Integer.valueOf(fowStutterAllele))).doubleValue() + fstut_mu));
                variances.put(Integer.valueOf(fowStutterAllele), Double.valueOf(((Double)variances.get(Integer.valueOf(fowStutterAllele))).doubleValue() + fstut_sigma * fstut_sigma));
              }
              else
              {
                means.put(Integer.valueOf(fowStutterAllele), Double.valueOf(fstut_mu));
                variances.put(Integer.valueOf(fowStutterAllele), Double.valueOf(fstut_sigma * fstut_sigma));
              }
            }
          }
        }
        for (NocitAlgorithm.Peak peakobj : allPeaks.values()) {
          if (!means.containsKey(Integer.valueOf(peakobj.getAllele())))
          {
            means.put(Integer.valueOf(peakobj.getAllele()), Double.valueOf(noise_mu));
            variances.put(Integer.valueOf(peakobj.getAllele()), Double.valueOf(noise_sigmasquared));
          }
        }
        double val_y = NocitAlgorithm.calcLocusPeakHeightsProb(allPeaks, means, variances);
        this.sum += val_y;
        Iterator i$;
        if (val_y > this.max_val)
        {
          this.max_val = val_y;
          this.max_alls.clear();
          for (i$ = selected_true_alleles.iterator(); i$.hasNext();)
          {
            int allele_name = ((Integer)i$.next()).intValue();
            this.max_alls.add(Integer.valueOf(allele_name));
          }
        }
        genotypes.clear();
        weights.clear();
        means.clear();
        variances.clear();
        true_alleles.clear();
        selected_true_alleles.clear();
        allPeaks.clear();
      }
      NocitAlgorithm.Callable_loci_object clobject = new NocitAlgorithm.Callable_loci_object(this.sum, this.max_val, this.max_alls);
      return clobject;
    }
  }
  
  private static HashMap<String, Integer> Final_Values = new HashMap();
  private static LinkedHashMap<String, LinkedHashMap<Integer, Integer>> Intervals_Map = new LinkedHashMap();
  private static ConcurrentHashMap<String, ConcurrentHashMap<Integer, Peak>> Loci_Peaks = new ConcurrentHashMap();
  private static HashMap<String, ArrayList<Integer>> Loci_Alleles = new HashMap();
  private static HashMap<String, ArrayList<String>> AMEL_Alleles = new HashMap();
  private static ConcurrentHashMap<String, ConcurrentHashMap<String, AMEL_Peak>> AMEL_Peaks = new ConcurrentHashMap();
  private static HashMap<String, double[]> True_Mean_Slope = new HashMap();
  private static HashMap<String, double[]> True_Stddev_Slope = new HashMap();
  private static HashMap<String, double[]> Noise_Mean_Slope = new HashMap();
  private static HashMap<String, double[]> Noise_Stddev_Slope = new HashMap();
  private static HashMap<String, double[]> R_Stutter_Mean = new HashMap();
  private static HashMap<String, double[]> R_Stutter_Stddev = new HashMap();
  private static HashMap<String, double[]> R_Stut_DO = new HashMap();
  private static HashMap<String, double[]> F_Stutter_Mean = new HashMap();
  private static HashMap<String, double[]> F_Stutter_Stddev = new HashMap();
  private static HashMap<String, double[]> F_Stut_DO = new HashMap();
  private static HashMap<String, double[]> Locus_DO = new HashMap();
  private static double DNA_Mass;
  private static String[] Sexes;
  private static HashMap<String, String[]> Sexes_Genotype;
  private static ArrayList<String> Sample_Loci;
  private String Freq_File;
  private String calibrationPath;
  private String Sample_File_Name;
  private String Output_File_Name;
  private int noc;
  private HashMap<Integer, BigDecimal> n_ans;
  private HashMap<Integer, BigDecimal> n_probdist;
  private HashMap<Integer, HashMap<String, BigDecimal>> n_locus_value;
  private HashMap<Integer, HashMap<String, Set<Integer>>> n_loci_max_alleles;
  private HashMap<Integer, HashMap<String, Set<String>>> n_amel_max_alleles;
  private HashMap<Integer, Double> time_taken;
  private HashSet<String> Working_Loci;
  private HashSet<String> Loci_RStutter;
  private HashSet<String> Loci_FStutter;
  private HashSet<String> Loci_no_true;
  private HashSet<String> Loci_no_noise;
  private HashSet<String> Loci_not_in_calib_samples;
  private HashSet<String> Loci_not_in_freq_table;
  
  public void printInterruptedNocitResults()
  {
    BigDecimal check1 = new BigDecimal(0);
    BigDecimal total = new BigDecimal(0);
    int final_n = 0;
    for (int n = 0; n <= this.noc; n++)
    {
      if (this.n_ans.get(Integer.valueOf(n)) == null)
      {
        final_n = n - 1;
        break;
      }
      total = total.add((BigDecimal)this.n_ans.get(Integer.valueOf(n)));
    }
    if (total.compareTo(check1) == 0) {
      for (int n = 0; n <= final_n; n++) {
        this.n_probdist.put(Integer.valueOf(n), new BigDecimal(0));
      }
    } else {
      for (int n = 0; n <= final_n; n++)
      {
        BigDecimal prob = ((BigDecimal)this.n_ans.get(Integer.valueOf(n))).divide(total, MathContext.DECIMAL128);
        if (prob.compareTo(check1) == 0) {
          this.n_probdist.put(Integer.valueOf(n), new BigDecimal(0));
        } else {
          this.n_probdist.put(Integer.valueOf(n), prob);
        }
      }
    }
    try
    {
      FileWriter fstream = new FileWriter(this.Output_File_Name);
      BufferedWriter output_file = new BufferedWriter(fstream);Throwable localThrowable2 = null;
      try
      {
        output_file.write("Calibration File: " + this.calibrationPath + "\n");
        output_file.write("Frequency File: " + this.Freq_File + "\n");
        output_file.write("Sample File: " + this.Sample_File_Name + "\n");
        output_file.write("Sample DNA input: " + DNA_Mass + "ng\n");
        output_file.write("\n");
        for (String locus : this.Loci_not_in_calib_samples) {
          output_file.write("Locus " + locus + " was not included in the calculation because it is not present in the calibration samples\n");
        }
        for (String locus : this.Loci_not_in_freq_table) {
          output_file.write("Locus " + locus + " was not included in the calculation because it is not present in the frequency table\n");
        }
        for (String locus : this.Loci_no_true) {
          output_file.write("Locus " + locus + " was not included in the calculation because it had too few data points for allelic peaks\n");
        }
        for (String locus : this.Loci_no_noise) {
          output_file.write("Locus " + locus + " was not included in the calculation because it had too few data points for noise peaks\n");
        }
        for (String locus : Sample_Loci) {
          if ((!this.Loci_RStutter.contains(locus)) && 
            (!locus.contentEquals("AMEL"))) {
            output_file.write("Locus " + locus + " had too few data points for reverse stutter \n");
          }
        }
        for (String locus : Sample_Loci) {
          if ((!this.Loci_FStutter.contains(locus)) && 
            (!locus.contentEquals("AMEL"))) {
            output_file.write("Locus " + locus + " had too few data points for forward stutter \n");
          }
        }
        output_file.write("\n");
        for (int n = 0; n <= final_n; n++) {
          if (this.n_ans.get(Integer.valueOf(n)) != null)
          {
            output_file.write("Number of contributors: " + n + "\n");
            output_file.write("Time taken: " + this.time_taken.get(Integer.valueOf(n)) + "m\n");
            if (n == 0)
            {
              for (String locus : this.Working_Loci) {
                output_file.write(locus + " = " + ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus) + "\n");
              }
              output_file.write("Likelihood: " + this.n_ans.get(Integer.valueOf(n)) + "\n");
              output_file.write("Probability: " + this.n_probdist.get(Integer.valueOf(n)) + "\n\n");
            }
            else
            {
              for (String locus : this.Working_Loci) {
                if (!locus.contentEquals("AMEL"))
                {
                  List<Integer> set_of_alleles = new ArrayList();
                  List<Double> true_alleles = new ArrayList();
                  for (Iterator i$ = ((Set)((HashMap)this.n_loci_max_alleles.get(Integer.valueOf(n))).get(locus)).iterator(); i$.hasNext();)
                  {
                    int allele = ((Integer)i$.next()).intValue();
                    set_of_alleles.add(Integer.valueOf(allele));
                  }
                  for (Iterator i$ = set_of_alleles.iterator(); i$.hasNext();)
                  {
                    int allele = ((Integer)i$.next()).intValue();
                    if (!((ArrayList)Loci_Alleles.get(locus)).contains(Integer.valueOf(allele)))
                    {
                      int index = set_of_alleles.indexOf(Integer.valueOf(allele));
                      set_of_alleles.set(index, Integer.valueOf(0));
                    }
                  }
                  for (Iterator i$ = set_of_alleles.iterator(); i$.hasNext();)
                  {
                    int allele = ((Integer)i$.next()).intValue();
                    true_alleles.add(Double.valueOf(allele / 10.0D));
                  }
                  output_file.write(locus + " = " + ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus) + " : " + true_alleles + "\n");
                }
                else
                {
                  List<String> set_of_alleles = new ArrayList();
                  set_of_alleles.addAll((Collection)((HashMap)this.n_amel_max_alleles.get(Integer.valueOf(n))).get(locus));
                  for (String allele : set_of_alleles) {
                    if (!((ArrayList)AMEL_Alleles.get(locus)).contains(allele))
                    {
                      int index = set_of_alleles.indexOf(allele);
                      set_of_alleles.set(index, String.valueOf(0));
                    }
                  }
                  output_file.write(locus + " = " + ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus) + " : " + set_of_alleles + "\n");
                }
              }
              output_file.write("Likelihood: " + this.n_ans.get(Integer.valueOf(n)) + "\n");
              output_file.write("Probability: " + this.n_probdist.get(Integer.valueOf(n)) + "\n\n");
            }
          }
        }
        output_file.close();
      }
      catch (Throwable localThrowable1)
      {
        localThrowable2 = localThrowable1;throw localThrowable1;
      }
      finally
      {
        if (output_file != null) {
          if (localThrowable2 != null) {
            try
            {
              output_file.close();
            }
            catch (Throwable x2)
            {
              localThrowable2.addSuppressed(x2);
            }
          } else {
            output_file.close();
          }
        }
      }
    }
    catch (Exception e)
    {
      System.err.println(e.getMessage());
    }
  }
  
  public void printNocitResults()
  {
    BigDecimal check1 = new BigDecimal(0);
    BigDecimal total = new BigDecimal(0);
    for (int n = 0; n <= this.noc; n++) {
      total = total.add((BigDecimal)this.n_ans.get(Integer.valueOf(n)));
    }
    if (total.compareTo(check1) == 0) {
      for (int n = 0; n <= this.noc; n++) {
        this.n_probdist.put(Integer.valueOf(n), new BigDecimal(0));
      }
    } else {
      for (int n = 0; n <= this.noc; n++)
      {
        BigDecimal prob = ((BigDecimal)this.n_ans.get(Integer.valueOf(n))).divide(total, MathContext.DECIMAL128);
        if (prob.compareTo(check1) == 0) {
          this.n_probdist.put(Integer.valueOf(n), new BigDecimal(0));
        } else {
          this.n_probdist.put(Integer.valueOf(n), prob);
        }
      }
    }
    try
    {
      FileWriter fstream = new FileWriter(this.Output_File_Name);
      BufferedWriter output_file = new BufferedWriter(fstream);Throwable localThrowable2 = null;
      try
      {
        output_file.write("Calibration File: " + this.calibrationPath + "\n");
        output_file.write("Frequency File: " + this.Freq_File + "\n");
        output_file.write("Sample File: " + this.Sample_File_Name + "\n");
        output_file.write("Sample DNA input: " + DNA_Mass + "ng\n");
        output_file.write("\n");
        for (String locus : this.Loci_not_in_calib_samples) {
          output_file.write("Locus " + locus + " was not included in the calculation because it is not present in the calibration samples\n");
        }
        for (String locus : this.Loci_not_in_freq_table) {
          output_file.write("Locus " + locus + " was not included in the calculation because it is not present in the frequency table\n");
        }
        for (String locus : this.Loci_no_true) {
          output_file.write("Locus " + locus + " was not included in the calculation because it had too few data points for allelic peaks\n");
        }
        for (String locus : this.Loci_no_noise) {
          output_file.write("Locus " + locus + " was not included in the calculation because it had too few data points for noise peaks\n");
        }
        for (String locus : Sample_Loci) {
          if ((!this.Loci_RStutter.contains(locus)) && 
            (!locus.contentEquals("AMEL"))) {
            output_file.write("Locus " + locus + " had too few data points for reverse stutter \n");
          }
        }
        for (String locus : Sample_Loci) {
          if ((!this.Loci_FStutter.contains(locus)) && 
            (!locus.contentEquals("AMEL"))) {
            output_file.write("Locus " + locus + " had too few data points for forward stutter \n");
          }
        }
        output_file.write("\n");
        for (int n = 0; n <= this.noc; n++) {
          if (this.n_ans.get(Integer.valueOf(n)) != null)
          {
            output_file.write("Number of contributors: " + n + "\n");
            output_file.write("Time taken: " + this.time_taken.get(Integer.valueOf(n)) + "m\n");
            if (n == 0)
            {
              for (String locus : this.Working_Loci) {
                output_file.write(locus + " = " + ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus) + "\n");
              }
              output_file.write("Likelihood: " + this.n_ans.get(Integer.valueOf(n)) + "\n");
              output_file.write("Probability: " + this.n_probdist.get(Integer.valueOf(n)) + "\n\n");
            }
            else
            {
              for (String locus : this.Working_Loci) {
                if (!locus.contentEquals("AMEL"))
                {
                  List<Integer> set_of_alleles = new ArrayList();
                  List<Double> true_alleles = new ArrayList();
                  for (Iterator i$ = ((Set)((HashMap)this.n_loci_max_alleles.get(Integer.valueOf(n))).get(locus)).iterator(); i$.hasNext();)
                  {
                    int allele = ((Integer)i$.next()).intValue();
                    set_of_alleles.add(Integer.valueOf(allele));
                  }
                  for (Iterator i$ = set_of_alleles.iterator(); i$.hasNext();)
                  {
                    int allele = ((Integer)i$.next()).intValue();
                    if (!((ArrayList)Loci_Alleles.get(locus)).contains(Integer.valueOf(allele)))
                    {
                      int index = set_of_alleles.indexOf(Integer.valueOf(allele));
                      set_of_alleles.set(index, Integer.valueOf(0));
                    }
                  }
                  for (Iterator i$ = set_of_alleles.iterator(); i$.hasNext();)
                  {
                    int allele = ((Integer)i$.next()).intValue();
                    true_alleles.add(Double.valueOf(allele / 10.0D));
                  }
                  output_file.write(locus + " = " + ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus) + " : " + true_alleles + "\n");
                }
                else
                {
                  List<String> set_of_alleles = new ArrayList();
                  set_of_alleles.addAll((Collection)((HashMap)this.n_amel_max_alleles.get(Integer.valueOf(n))).get(locus));
                  for (String allele : set_of_alleles) {
                    if (!((ArrayList)AMEL_Alleles.get(locus)).contains(allele))
                    {
                      int index = set_of_alleles.indexOf(allele);
                      set_of_alleles.set(index, String.valueOf(0));
                    }
                  }
                  output_file.write(locus + " = " + ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus) + " : " + set_of_alleles + "\n");
                }
              }
              output_file.write("Likelihood: " + this.n_ans.get(Integer.valueOf(n)) + "\n");
              output_file.write("Probability: " + this.n_probdist.get(Integer.valueOf(n)) + "\n\n");
            }
          }
        }
        output_file.close();
      }
      catch (Throwable localThrowable1)
      {
        localThrowable2 = localThrowable1;throw localThrowable1;
      }
      finally
      {
        if (output_file != null) {
          if (localThrowable2 != null) {
            try
            {
              output_file.close();
            }
            catch (Throwable x2)
            {
              localThrowable2.addSuppressed(x2);
            }
          } else {
            output_file.close();
          }
        }
      }
    }
    catch (Exception e)
    {
      System.err.println(e.getMessage());
    }
  }
  
  public void runNocit(File sampleFile, File frequencyFile, File outputFile, File calibrationFile, int maxNumberContributors, double dnaMass, JProgressBar progBar)
    throws InterruptedException, ExecutionException, FunctionEvaluationException, IOException, OptimizationException
  {
    double epsilon = 0.001D;
    int[] loci_increments = { 100000, 10000000, 60000000, 120000000, 200000000 };
    int[] amel_increments = { 50000, 1000000, 6000000, 60000000, 120000000 };
    LevenbergMarquardtOptimizer lmo = new LevenbergMarquardtOptimizer();
    lmo.setMaxIterations(1000000);
    int step_size = 1000000;
    BigDecimal check = new BigDecimal(0);
    int num_processors = Runtime.getRuntime().availableProcessors();
    int corePoolSize = num_processors;
    int maxPoolSize = num_processors;
    long keepAliveTime = 5L;
    
    this.n_probdist = new HashMap();
    this.n_ans = new HashMap();
    this.n_locus_value = new HashMap();
    this.n_loci_max_alleles = new HashMap();
    this.n_amel_max_alleles = new HashMap();
    this.time_taken = new HashMap();
    this.Loci_no_true = new HashSet();
    this.Loci_no_noise = new HashSet();
    this.Loci_RStutter = new HashSet();
    this.Loci_FStutter = new HashSet();
    this.Loci_not_in_freq_table = new HashSet();
    this.Loci_not_in_calib_samples = new HashSet();
    this.Working_Loci = new HashSet();
    
    String male = "M";String female = "F";
    Sexes = new String[] { "M", "F" };
    String[] male_genotype = { "X", "Y" };
    String[] female_genotype = { "X", "X" };
    Sexes_Genotype = new HashMap();
    Sexes_Genotype.put(male, male_genotype);
    Sexes_Genotype.put(female, female_genotype);
    

    this.Freq_File = frequencyFile.getAbsolutePath();
    this.calibrationPath = calibrationFile.getAbsolutePath();
    this.Sample_File_Name = sampleFile.getAbsolutePath();
    this.Output_File_Name = outputFile.getAbsolutePath();
    DNA_Mass = dnaMass;
    this.noc = maxNumberContributors;
    
    FreqTable FreqTableObject = new FreqTable(this.Freq_File);
    LinkedHashMap<String, LinkedHashMap<Integer, Double>> Freq_Table = FreqTableObject.getFreqTable();
    ArrayList<String> Freq_Loci = FreqTableObject.getFreqLociList();
    Intervals_Map = intervals(Freq_Table, Freq_Loci);
    for (String locus : Freq_Loci)
    {
      Set<Integer> keys_set = ((LinkedHashMap)Intervals_Map.get(locus)).keySet();
      List<Integer> keys_array = new ArrayList();
      keys_array.addAll(keys_set);
      Integer last_key = (Integer)keys_array.get(keys_array.size() - 1);
//      Integer last_key = (Integer)keys_array.get(keys_array.size());
        
Final_Values.put(locus, last_key);
    }
    parseSampleFile pSFObject = new parseSampleFile(this.Sample_File_Name);
    Loci_Peaks = pSFObject.getLociPeaks();
    Loci_Alleles = pSFObject.getLociAlleles();
    AMEL_Peaks = pSFObject.getAMELPeaks();
    AMEL_Alleles = pSFObject.getAMELAlleles();
    Sample_Loci = pSFObject.getSampleLoci();
    
    CalibDataCollection cdcobject = new CalibDataCollection(this.calibrationPath, Freq_Table);
    HashMap<Double, HashMap<String, Double>> Calib_DO = cdcobject.getDOCalibData();
    HashMap<Double, HashMap<String, Double>> Calib_rstutDO = cdcobject.getrstutDOCalibData();
    HashMap<Double, HashMap<String, Double>> Calib_fstutDO = cdcobject.getfstutDOCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_True = cdcobject.getTrueCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_Noise = cdcobject.getNoiseCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_rstut = cdcobject.getrstutterCalibData();
    HashMap<Double, HashMap<String, ArrayList<Double>>> Calib_fstut = cdcobject.getfstutterCalibData();
    HashSet<String> Calib_Loci = cdcobject.getLoci();
    HashSet<Double> Calib_Masses = cdcobject.getMasses();
    ArrayList<Double> calib_masses = new ArrayList(Calib_Masses);
    Collections.sort(calib_masses);
    HashSet<String> Loci_cannot_work = new HashSet();
    
    True_Mean_Slope = new HashMap();
    True_Stddev_Slope = new HashMap();
    Noise_Mean_Slope = new HashMap();
    Noise_Stddev_Slope = new HashMap();
    R_Stutter_Mean = new HashMap();
    R_Stutter_Stddev = new HashMap();
    F_Stutter_Mean = new HashMap();
    F_Stutter_Stddev = new HashMap();
    Locus_DO = new HashMap();
    R_Stut_DO = new HashMap();
    F_Stut_DO = new HashMap();
    for (String locus : Calib_Loci)
    {
      ArrayList<Double> total_True_Masses = new ArrayList();
      ArrayList<Double> total_noise_Masses = new ArrayList();
      ArrayList<Double> total_rstut_Masses = new ArrayList();
      ArrayList<Double> total_fstut_Masses = new ArrayList();
      ArrayList<Double> total_DO_Masses = new ArrayList();
      ArrayList<Double> total_rstutDO_Masses = new ArrayList();
      ArrayList<Double> total_fstutDO_Masses = new ArrayList();
      

      CurveFitter truemean_fitter = new CurveFitter(lmo);
      CurveFitter truestddev_fitter = new CurveFitter(lmo);
      CurveFitter noisemean_fitter = new CurveFitter(lmo);
      CurveFitter noisestddev_fitter = new CurveFitter(lmo);
      CurveFitter rstutmean_fitter = new CurveFitter(lmo);
      CurveFitter rstutstddev_fitter = new CurveFitter(lmo);
      CurveFitter fstutmean_fitter = new CurveFitter(lmo);
      CurveFitter fstutstddev_fitter = new CurveFitter(lmo);
      CurveFitter do_fitter = new CurveFitter(lmo);
      CurveFitter rstutdo_fitter = new CurveFitter(lmo);
      CurveFitter fstutdo_fitter = new CurveFitter(lmo);
      

      double[] truemean_init = { 3000.0D, 30.0D };
      double[] truestddev_init = { 1000.0D, 50.0D };
      double[] noisemean_init = { 50.0D, 5.0D };
      double[] noisestddev_init = { 100.0D, 0.0D };
      double[] rstutmean_init = { 0.0D, -50.0D, 0.0D };
      double[] rstutstddev_init = { 0.0D, -50.0D, 0.0D };
      double[] fstutmean_init = { 0.0D, -50.0D, 0.0D };
      double[] fstutstddev_init = { 0.0D, -50.0D, 0.0D };
      double[] do_init = { 0.0D, -100.0D };
      double[] rstutdo_init = { 0.0D, -30.0D };
      double[] fstutdo_init = { 0.0D, -5.0D };
      for (Iterator i$ = calib_masses.iterator(); i$.hasNext();)
      {
        double mass = ((Double)i$.next()).doubleValue();
        Double true_mean = (Double)((ArrayList)((HashMap)Calib_True.get(Double.valueOf(mass))).get(locus)).get(0);
        Double true_stddev = (Double)((ArrayList)((HashMap)Calib_True.get(Double.valueOf(mass))).get(locus)).get(1);
        if ((!true_stddev.isNaN()) && (true_stddev.doubleValue() != 0.0D))
        {
          total_True_Masses.add(Double.valueOf(mass));
          truemean_fitter.addObservedPoint(mass, true_mean.doubleValue());
          truestddev_fitter.addObservedPoint(mass, true_stddev.doubleValue());
        }
        Double noise_meanval = (Double)((ArrayList)((HashMap)Calib_Noise.get(Double.valueOf(mass))).get(locus)).get(0);
        Double noise_stddevval = (Double)((ArrayList)((HashMap)Calib_Noise.get(Double.valueOf(mass))).get(locus)).get(1);
        if ((!noise_stddevval.isNaN()) && (noise_stddevval.doubleValue() != 0.0D))
        {
          total_noise_Masses.add(Double.valueOf(mass));
          noisemean_fitter.addObservedPoint(mass, noise_meanval.doubleValue());
          noisestddev_fitter.addObservedPoint(mass, noise_stddevval.doubleValue());
        }
        Double DOval = (Double)((HashMap)Calib_DO.get(Double.valueOf(mass))).get(locus);
        if (!DOval.isInfinite())
        {
          total_DO_Masses.add(Double.valueOf(mass));
          do_fitter.addObservedPoint(mass, DOval.doubleValue());
        }
        if (!locus.contentEquals("AMEL"))
        {
          Double rstutDOval = (Double)((HashMap)Calib_rstutDO.get(Double.valueOf(mass))).get(locus);
          if (!rstutDOval.isInfinite())
          {
            total_rstutDO_Masses.add(Double.valueOf(mass));
            rstutdo_fitter.addObservedPoint(mass, rstutDOval.doubleValue());
          }
          Double rstut_meanval = (Double)((ArrayList)((HashMap)Calib_rstut.get(Double.valueOf(mass))).get(locus)).get(0);
          Double rstut_stddevval = (Double)((ArrayList)((HashMap)Calib_rstut.get(Double.valueOf(mass))).get(locus)).get(1);
          if ((!rstut_stddevval.isNaN()) && (rstut_stddevval.doubleValue() != 0.0D))
          {
            rstutmean_fitter.addObservedPoint(mass, rstut_meanval.doubleValue());
            rstutstddev_fitter.addObservedPoint(mass, rstut_stddevval.doubleValue());
            total_rstut_Masses.add(Double.valueOf(mass));
          }
          Double fstutDOval = (Double)((HashMap)Calib_fstutDO.get(Double.valueOf(mass))).get(locus);
          if (!fstutDOval.isInfinite())
          {
            total_fstutDO_Masses.add(Double.valueOf(mass));
            fstutdo_fitter.addObservedPoint(mass, fstutDOval.doubleValue());
          }
          Double fstut_meanval = (Double)((ArrayList)((HashMap)Calib_fstut.get(Double.valueOf(mass))).get(locus)).get(0);
          Double fstut_stddevval = (Double)((ArrayList)((HashMap)Calib_fstut.get(Double.valueOf(mass))).get(locus)).get(1);
          if ((!fstut_stddevval.isNaN()) && (fstut_stddevval.doubleValue() != 0.0D))
          {
            fstutmean_fitter.addObservedPoint(mass, fstut_meanval.doubleValue());
            fstutstddev_fitter.addObservedPoint(mass, fstut_stddevval.doubleValue());
            total_fstut_Masses.add(Double.valueOf(mass));
          }
        }
      }
      double[] truemean_best = new double[2];
      double[] truestddev_best = new double[2];
      double[] noisemean_best = new double[2];
      double[] noisestddev_best = new double[2];
      double[] rstutmean_best = new double[3];
      double[] rstutstddev_best = new double[3];
      double[] fstutmean_best = new double[3];
      double[] fstutstddev_best = new double[3];
      double[] do_best = { 0.0D, 0.0D };
      double[] rstutdo_best = { 0.0D, 0.0D };
      double[] fstutdo_best = { 0.0D, 0.0D };
      if (total_True_Masses.size() > 1)
      {
        truemean_best = truemean_fitter.fit(new LinFunction(null), truemean_init);
        truestddev_best = truestddev_fitter.fit(new LinFunction(null), truestddev_init);
      }
      else
      {
        Loci_cannot_work.add(locus);
        this.Loci_no_true.add(locus);
      }
      if (total_noise_Masses.size() > 1)
      {
        noisemean_best = noisemean_fitter.fit(new LinFunction(null), noisemean_init);
        noisestddev_best = noisestddev_fitter.fit(new LinFunction(null), noisestddev_init);
      }
      else
      {
        Loci_cannot_work.add(locus);
        this.Loci_no_noise.add(locus);
      }
      if (total_DO_Masses.size() > 1) {
        do_best = do_fitter.fit(new ExpFunction(null), do_init);
      }
      if (!locus.contentEquals("AMEL"))
      {
        if (total_rstut_Masses.size() > 2)
        {
          rstutmean_best = rstutmean_fitter.fit(new TwoExpFunction(null), rstutmean_init);
          rstutstddev_best = rstutstddev_fitter.fit(new TwoExpFunction(null), rstutstddev_init);
          this.Loci_RStutter.add(locus);
        }
        if (total_fstut_Masses.size() > 2)
        {
          fstutmean_best = fstutmean_fitter.fit(new TwoExpFunction(null), fstutmean_init);
          fstutstddev_best = fstutstddev_fitter.fit(new TwoExpFunction(null), fstutstddev_init);
          this.Loci_FStutter.add(locus);
        }
        if (total_rstutDO_Masses.size() > 1) {
          rstutdo_best = rstutdo_fitter.fit(new ExpFunction(null), rstutdo_init);
        }
        if (total_fstutDO_Masses.size() > 1) {
          fstutdo_best = fstutdo_fitter.fit(new ExpFunction(null), fstutdo_init);
        }
      }
      if (!Loci_cannot_work.contains(locus))
      {
        True_Mean_Slope.put(locus, truemean_best);
        True_Stddev_Slope.put(locus, truestddev_best);
        Noise_Mean_Slope.put(locus, noisemean_best);
        Noise_Stddev_Slope.put(locus, noisestddev_best);
        Locus_DO.put(locus, do_best);
      }
      if (!locus.contentEquals("AMEL"))
      {
        if (this.Loci_RStutter.contains(locus))
        {
          if (rstutmean_best[2] >= 0.0D)
          {
            R_Stutter_Mean.put(locus, rstutmean_best);
          }
          else
          {
            double[] rstutmean = rstutmean_fitter.fit(new PosTwoExpFunction(null), rstutmean_init);
            if (rstutmean[2] >= 0.0D)
            {
              R_Stutter_Mean.put(locus, rstutmean);
            }
            else
            {
              double[] new_rstutmean_best = { rstutmean[0], rstutmean[1], 0.0D };
              R_Stutter_Mean.put(locus, new_rstutmean_best);
            }
          }
          if (rstutstddev_best[2] >= 0.0D)
          {
            R_Stutter_Stddev.put(locus, rstutstddev_best);
          }
          else
          {
            double[] rstutstddev = rstutstddev_fitter.fit(new PosTwoExpFunction(null), rstutstddev_init);
            if (rstutstddev[2] >= 0.0D)
            {
              R_Stutter_Stddev.put(locus, rstutstddev);
            }
            else
            {
              double[] new_rstutstddev_best = { rstutstddev[0], rstutstddev[1], 0.0D };
              R_Stutter_Stddev.put(locus, new_rstutstddev_best);
            }
          }
          R_Stut_DO.put(locus, rstutdo_best);
        }
        if (this.Loci_FStutter.contains(locus))
        {
          if (fstutmean_best[2] >= 0.0D)
          {
            F_Stutter_Mean.put(locus, fstutmean_best);
          }
          else
          {
            double[] fstutmean = fstutmean_fitter.fit(new PosTwoExpFunction(null), fstutmean_init);
            if (fstutmean[2] >= 0.0D)
            {
              F_Stutter_Mean.put(locus, fstutmean);
            }
            else
            {
              double[] new_fstutmean_best = { fstutmean[0], fstutmean[1], 0.0D };
              F_Stutter_Mean.put(locus, new_fstutmean_best);
            }
          }
          if (fstutstddev_best[2] >= 0.0D)
          {
            F_Stutter_Stddev.put(locus, fstutstddev_best);
          }
          else
          {
            double[] fstutstddev = fstutstddev_fitter.fit(new PosTwoExpFunction(null), fstutstddev_init);
            if (fstutstddev[2] >= 0.0D)
            {
              F_Stutter_Stddev.put(locus, fstutstddev);
            }
            else
            {
              double[] new_fstutstddev_best = { fstutstddev[0], fstutstddev[1], 0.0D };
              F_Stutter_Stddev.put(locus, new_fstutstddev_best);
            }
          }
          F_Stut_DO.put(locus, fstutdo_best);
        }
      }
    }
    for (String locus : Sample_Loci) {
      if (Calib_Loci.contains(locus))
      {
        if (!Loci_cannot_work.contains(locus)) {
          if (!locus.contentEquals("AMEL"))
          {
            if (Freq_Loci.contains(locus)) {
              this.Working_Loci.add(locus);
            } else {
              this.Loci_not_in_freq_table.add(locus);
            }
          }
          else {
            this.Working_Loci.add(locus);
          }
        }
      }
      else {
        this.Loci_not_in_calib_samples.add(locus);
      }
    }
    for (int n = 0; n <= this.noc; n++) {
      if (n == 0)
      {
        double initial_time = System.currentTimeMillis();
        this.n_locus_value.put(Integer.valueOf(n), new HashMap());
        for (String locus : this.Working_Loci) {
          if (!locus.contentEquals("AMEL"))
          {
            HashMap<Integer, Double> means = new HashMap();
            HashMap<Integer, Double> variances = new HashMap();
            ConcurrentHashMap<Integer, Peak> all_peaks = (ConcurrentHashMap)Loci_Peaks.get(locus);
            for (Peak peakobj : all_peaks.values())
            {
              double[] values = calcSlopeValue(locus, DNA_Mass, Noise_Mean_Slope, Noise_Stddev_Slope);
              double noise_mu = values[0];
              double noise_sigmasquared = values[1] * values[1];
              means.put(Integer.valueOf(peakobj.getAllele()), Double.valueOf(noise_mu));
              variances.put(Integer.valueOf(peakobj.getAllele()), Double.valueOf(noise_sigmasquared));
            }
            double val_y = calcLocusPeakHeightsProb(all_peaks, means, variances);
            BigDecimal locus_val = new BigDecimal(val_y, MathContext.DECIMAL128);
            ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).put(locus, locus_val);
          }
          else
          {
            HashMap<String, Double> means = new HashMap();
            HashMap<String, Double> variances = new HashMap();
            ConcurrentHashMap<String, AMEL_Peak> all_peaks = (ConcurrentHashMap)AMEL_Peaks.get(locus);
            for (AMEL_Peak peakobj : all_peaks.values())
            {
              double[] values = calcSlopeValue(locus, DNA_Mass, Noise_Mean_Slope, Noise_Stddev_Slope);
              double noise_mu = values[0];
              double noise_sigmasquared = values[1] * values[1];
              means.put(peakobj.getAllele(), Double.valueOf(noise_mu));
              variances.put(peakobj.getAllele(), Double.valueOf(noise_sigmasquared));
            }
            double val_y = calcAMELPeakHeightsProb(all_peaks, means, variances);
            BigDecimal locus_val = new BigDecimal(val_y, MathContext.DECIMAL128);
            ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).put(locus, locus_val);
          }
        }
        BigDecimal n_val = new BigDecimal(1, MathContext.DECIMAL128);
        for (String locus : this.Working_Loci)
        {
          BigDecimal val = (BigDecimal)((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus);
          n_val = n_val.multiply(val, MathContext.DECIMAL128);
        }
        if (n_val.compareTo(check) == 0) {
          this.n_ans.put(Integer.valueOf(n), new BigDecimal(0));
        } else {
          this.n_ans.put(Integer.valueOf(n), n_val);
        }
        double final_time = System.currentTimeMillis();
        double time = (final_time - initial_time) / 60000.0D;
        double time_ans = Math.round(time * 100.0D) / 100.0D;
        this.time_taken.put(Integer.valueOf(n), Double.valueOf(time_ans));
      }
      else
      {
        double initial_time = System.currentTimeMillis();
        this.n_loci_max_alleles.put(Integer.valueOf(n), new HashMap());
        this.n_amel_max_alleles.put(Integer.valueOf(n), new HashMap());
        this.n_locus_value.put(Integer.valueOf(n), new HashMap());
        HashMap<String, Double> Max_Val = new HashMap();
        HashMap<String, ArrayList<Double>> locus_vals = new HashMap();
        HashMap<String, ArrayList<Double>> locus_zerovals = new HashMap();
        for (String locus : this.Working_Loci)
        {
          Max_Val.put(locus, Double.valueOf(0.0D));
          locus_vals.put(locus, new ArrayList());
          locus_zerovals.put(locus, new ArrayList());
          double running_value = 0.0D;
          boolean not_reached = true;
          double iterations;
          int increment;
          int split;
          //double iterations;
          if (!locus.contentEquals("AMEL"))
          {
             increment = loci_increments[(n - 1)];
             split = increment / num_processors;
            iterations = loci_increments[(n - 1)];
          }
          else
          {
            increment = amel_increments[(n - 1)];
            split = increment / num_processors;
            iterations = amel_increments[(n - 1)];
          }
          while (not_reached)
          {
            if (!locus.contentEquals("AMEL"))
            {
              if (n < 2)
              {
                ExecutorService Executor = Executors.newFixedThreadPool(num_processors);
                Set<Sum_threads_stutterloci> Callables = new HashSet();
                for (int i = 1; i <= num_processors; i++) {
                  Callables.add(new Sum_threads_stutterloci(split, n, locus, this.Loci_RStutter, this.Loci_FStutter));
                }
                List<Future<Callable_loci_object>> Futures = Executor.invokeAll(Callables);
                for (Future<Callable_loci_object> future : Futures)
                {
                  Callable_loci_object clobject = (Callable_loci_object)future.get();
                  running_value += clobject.getvalue();
                  if (clobject.getmaxvalue() > ((Double)Max_Val.get(locus)).doubleValue())
                  {
                    Max_Val.put(locus, Double.valueOf(clobject.getmaxvalue()));
                    ((HashMap)this.n_loci_max_alleles.get(Integer.valueOf(n))).put(locus, clobject.getmaxalls());
                  }
                }
                Executor.shutdown();
              }
              else
              {
                int step = 0;
                List<Future<Callable_loci_object>> futures = new ArrayList();
                ThreadPoolExecutor tpe = new ThreadPoolExecutor(corePoolSize, maxPoolSize, keepAliveTime, TimeUnit.MINUTES, new LinkedBlockingQueue());
                while (step < increment)
                {
                  int inactive_processors = num_processors - tpe.getActiveCount();
                  for (int i = 1; i <= inactive_processors; i++) {
                    if (step < increment)
                    {
                      step += step_size;
                      Future<Callable_loci_object> future = tpe.submit(new Sum_threads_stutterloci(step_size, n, locus, this.Loci_RStutter, this.Loci_FStutter));
                      futures.add(future);
                    }
                  }
                }
                for (Future<Callable_loci_object> future : futures)
                {
                  Callable_loci_object clobject = (Callable_loci_object)future.get();
                  running_value += clobject.getvalue();
                  if (clobject.getmaxvalue() > ((Double)Max_Val.get(locus)).doubleValue())
                  {
                    Max_Val.put(locus, Double.valueOf(clobject.getmaxvalue()));
                    ((HashMap)this.n_loci_max_alleles.get(Integer.valueOf(n))).put(locus, clobject.getmaxalls());
                  }
                }
              }
            }
            else if (n <= 3)
            {
              ExecutorService Executor = Executors.newFixedThreadPool(num_processors);
              Set<Sum_threads_amel> Callables = new HashSet();
              for (int i = 1; i <= num_processors; i++) {
                Callables.add(new Sum_threads_amel(split, n, locus));
              }
              List<Future<Callable_amel_object>> Futures = Executor.invokeAll(Callables);
              for (Future<Callable_amel_object> future : Futures)
              {
                Callable_amel_object clobject = (Callable_amel_object)future.get();
                running_value += clobject.getvalue();
                if (clobject.getmaxvalue() > ((Double)Max_Val.get(locus)).doubleValue())
                {
                  Max_Val.put(locus, Double.valueOf(clobject.getmaxvalue()));
                  ((HashMap)this.n_amel_max_alleles.get(Integer.valueOf(n))).put(locus, clobject.getmaxalls());
                }
              }
              Executor.shutdown();
            }
            else
            {
              int step = 0;
              List<Future<Callable_amel_object>> futures = new ArrayList();
              ThreadPoolExecutor tpe = new ThreadPoolExecutor(corePoolSize, maxPoolSize, keepAliveTime, TimeUnit.MINUTES, new LinkedBlockingQueue());
              while (step < increment)
              {
                int inactive_processors = num_processors - tpe.getActiveCount();
                for (int i = 1; i <= inactive_processors; i++) {
                  if (step < increment)
                  {
                    step += step_size;
                    Future<Callable_amel_object> future = tpe.submit(new Sum_threads_amel(step_size, n, locus));
                    futures.add(future);
                  }
                }
              }
              for (Future<Callable_amel_object> future : futures)
              {
                Callable_amel_object clobject = (Callable_amel_object)future.get();
                running_value += clobject.getvalue();
                if (clobject.getmaxvalue() > ((Double)Max_Val.get(locus)).doubleValue())
                {
                  Max_Val.put(locus, Double.valueOf(clobject.getmaxvalue()));
                  ((HashMap)this.n_amel_max_alleles.get(Integer.valueOf(n))).put(locus, clobject.getmaxalls());
                }
              }
            }
            double present_value = running_value / iterations;
            double present_transformed_value = Math.log10(present_value);
            if (present_transformed_value != (-1.0D / 0.0D))
            {
              ((ArrayList)locus_vals.get(locus)).add(Double.valueOf(present_transformed_value));
              if (((ArrayList)locus_vals.get(locus)).size() > 1)
              {
                double prev_value = ((Double)((ArrayList)locus_vals.get(locus)).get(((ArrayList)locus_vals.get(locus)).size() - 2)).doubleValue();
                double perc_change = Math.abs((present_transformed_value - prev_value) / prev_value);
                if (perc_change <= epsilon)
                {
                  not_reached = false;
                  BigDecimal locus_answer = new BigDecimal(present_value, MathContext.DECIMAL128);
                  ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).put(locus, locus_answer);
                }
                else
                {
                  iterations += increment;
                }
              }
              else
              {
                iterations += increment;
              }
            }
            else
            {
              ((ArrayList)locus_zerovals.get(locus)).add(Double.valueOf(present_transformed_value));
              if (((ArrayList)locus_zerovals.get(locus)).size() > 1)
              {
                not_reached = false;
                ((HashMap)this.n_locus_value.get(Integer.valueOf(n))).put(locus, new BigDecimal(0));
              }
              else
              {
                iterations += increment;
              }
            }
          }
        }
        BigDecimal n_val = new BigDecimal(1, MathContext.DECIMAL128);
        for (String locus : this.Working_Loci)
        {
          BigDecimal val = (BigDecimal)((HashMap)this.n_locus_value.get(Integer.valueOf(n))).get(locus);
          n_val = n_val.multiply(val, MathContext.DECIMAL128);
          if (locus.contentEquals("AMEL"))
          {
            if (((HashMap)this.n_amel_max_alleles.get(Integer.valueOf(n))).get(locus) == null) {
              ((HashMap)this.n_amel_max_alleles.get(Integer.valueOf(n))).put(locus, new HashSet());
            }
          }
          else if (((HashMap)this.n_loci_max_alleles.get(Integer.valueOf(n))).get(locus) == null) {
            ((HashMap)this.n_loci_max_alleles.get(Integer.valueOf(n))).put(locus, new HashSet());
          }
        }
        if (n_val.compareTo(check) == 0) {
          this.n_ans.put(Integer.valueOf(n), new BigDecimal(0));
        } else {
          this.n_ans.put(Integer.valueOf(n), n_val);
        }
        double final_time = System.currentTimeMillis();
        double time = (final_time - initial_time) / 60000.0D;
        double time_ans = Math.round(time * 100.0D) / 100.0D;
        this.time_taken.put(Integer.valueOf(n), Double.valueOf(time_ans));
      }
    }
  }
}

