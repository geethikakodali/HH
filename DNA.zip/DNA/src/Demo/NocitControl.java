/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Demo;

/**
 *
 * @author Lunar
 */


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.concurrent.ExecutionException;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.optimization.OptimizationException;

public class NocitControl
  implements ActionListener
{
  private NocitWindow ui;
  private NocitInputs inputs;
  private NocitThread nocitThread;
  private JProgressBar progressBar;
  private JFileChooser fileChooser = new JFileChooser();
  private NocitAlgorithm nocitAlgorithm;
  private final FileNameExtensionFilter textFileFilter = new FileNameExtensionFilter("txt", new String[] { "txt" });
  private final FileNameExtensionFilter csvFileFilter = new FileNameExtensionFilter("csv", new String[] { "csv" });
  
  public NocitControl(NocitWindow ui, NocitInputs inputs)
  {
    this.ui = ui;
    this.inputs = inputs;
    this.nocitThread = new NocitThread();
    this.nocitAlgorithm = new NocitAlgorithm();
    this.progressBar = ui.getProgressBar();
    ui.setVisible(true);
    ui.addActionListenerToAllButtons(this);
  }
  
  public void runNocit()
  {
    this.progressBar.setIndeterminate(true);
    this.progressBar.setString("running");
    
    boolean stoppedBeforeCompletion = false;
    try
    {
      this.nocitAlgorithm.runNocit(this.inputs.getSampleFile(), this.inputs.getFrequencyFile(), this.inputs.getOutputFile(), this.inputs.getCalibrationFile(), this.inputs.getMaxNumberOfContributors(), this.inputs.getDNAMass(), this.progressBar);
      this.nocitAlgorithm.printNocitResults();
    }
    catch (ExecutionException|IOException|FunctionEvaluationException|OptimizationException e)
    {
      System.out.println(e.getMessage());
    }
    catch (InterruptedException ex)
    {
      stoppedBeforeCompletion = true;
      this.nocitAlgorithm.printInterruptedNocitResults();
    }
    this.nocitThread = new NocitThread();
    if (stoppedBeforeCompletion) {
      JOptionPane.showMessageDialog(this.ui, "The program was stopped before completing computation");
    } else {
      JOptionPane.showMessageDialog(this.ui, "The program has finished running");
    }
    this.ui.setStartButtonEnabled(Boolean.TRUE);
    this.progressBar.setString("");
    this.progressBar.setIndeterminate(false);
  }
  
  public void actionPerformed(ActionEvent e)
  {
    switch (e.getActionCommand())
    {
    case "frequency": 
      File file = getFile("Select Frequency File", this.csvFileFilter);
      if (file != null)
      {
        this.ui.setFrequencyFileSelectionText(file.getName());
        this.inputs.setFrequencyFile(file);
      }
      break;
    case "calibration": 
       file = getFile("Select Calibration File", this.csvFileFilter);
      if (file != null)
      {
        this.ui.setCalibrationFileSelectionText(file.getName());
        this.inputs.setCalibrationFile(file);
      }
      break;
    case "sample": 
       file = getFile("Select Sample File", this.csvFileFilter);
      if (file != null)
      {
        this.ui.setSampleFileSelectionText(file.getName());
        this.inputs.setSampleFile(file);
      }
      break;
    case "output": 
       file = makeFile("Select/Create Output File", this.textFileFilter);
      if (file != null)
      {
        this.ui.setOutputFileSelectionText(file.getName());
        this.inputs.setOutputFile(file);
      }
      break;
    case "start": 
      boolean start = true;
      if ((this.inputs.getOutputFile() != null) && (this.inputs.getOutputFile().exists()) && (this.inputs.getOutputFile().length() != 0L))
      {
        int paneReturn = JOptionPane.showConfirmDialog(this.ui, "The file " + this.inputs.getOutputFile().getName() + " contains  program output. Do you want to overwrite it?", "Overwrite file?", 0);
        if (paneReturn != 0) {
          start = false;
        }
      }
      if ((start == true) && (this.inputs.updateNumericFields(this.ui.getDNAMassSelectionText(), this.ui.getMaxNoContibutorsText())) && (this.inputs.allFieldsValid()))
      {
        if (this.inputs.getOutputFile() == null)
        {
          this.inputs.setOutputFile(new File(getAbsoluteFilePathWithoutExtension(this.inputs.getSampleFile()) + "_NOCIt_output.txt"));
          this.ui.setOutputFileSelectionText(this.inputs.getOutputFile().getName());
        }
        this.nocitThread.start();
        this.ui.setStartButtonEnabled(Boolean.FALSE);
      }
      displayNumericFieldErrors();
      break;
    default: 
      this.nocitThread.interrupt();
      this.progressBar.setString("");
      this.progressBar.setIndeterminate(false);
    }
  }
  
  private File getFile(String message, FileNameExtensionFilter filter)
  {
    this.fileChooser.setDialogTitle(message);
    this.fileChooser.setFileFilter(filter);
    int chooserReturn = this.fileChooser.showOpenDialog(this.ui);
    File selectedFile = null;
    if (chooserReturn == 0) {
      selectedFile = this.fileChooser.getSelectedFile();
    }
    return selectedFile;
  }
  
  private File makeFile(String message, FileNameExtensionFilter filter)
  {
    this.fileChooser.setFileFilter(filter);
    this.fileChooser.setDialogTitle(message);
    int chooserReturn = this.fileChooser.showSaveDialog(this.ui);
    File createdFile = null;
    if (chooserReturn == 0)
    {
      createdFile = this.fileChooser.getSelectedFile();
      if (createdFile.exists())
      {
        int paneReturn = JOptionPane.showConfirmDialog(this.ui, "The file \"" + createdFile.getName() + "\" exists and will be overwritten by the output of the program. Do you want to continue?", "Overwrite file?", 0);
        if (paneReturn == 0)
        {
          createdFile.delete();
          try
          {
            createdFile.createNewFile();
          }
          catch (IOException e)
          {
            System.out.println(e.getMessage());
          }
        }
        else
        {
          createdFile = null;
        }
      }
      else
      {
        String pathName = createdFile.getAbsolutePath();
        int begin = pathName.length() - 4;
        if (!createdFile.getAbsolutePath().substring(begin).equals(".txt")) {
          createdFile = new File(createdFile.getAbsolutePath().concat(".txt"));
        }
        try
        {
          createdFile.createNewFile();
        }
        catch (IOException e)
        {
          System.out.println(e.getMessage());
        }
      }
    }
    return createdFile;
  }
  
  private String getAbsoluteFilePathWithoutExtension(File file)
  {
    int end = file.getAbsolutePath().length() - 4;
    return this.inputs.getSampleFile().getAbsolutePath().substring(0, end);
  }
  
  private void displayNumericFieldErrors()
  {
    String dnaMassError = this.inputs.getDnaMassError();
    String maxNumberOfContributorsError = this.inputs.getMaxNumberOfContributorsError();
    if ((!dnaMassError.equals("")) && (!maxNumberOfContributorsError.equals(""))) {
      JOptionPane.showMessageDialog(this.ui, "Inputs for \"DNA mass\" and \"maximum number of contributors\" are not valid");
    } else if ((!dnaMassError.equals("")) && (maxNumberOfContributorsError.equals(""))) {
      JOptionPane.showMessageDialog(this.ui, dnaMassError);
    } else if ((dnaMassError.equals("")) && (!maxNumberOfContributorsError.equals(""))) {
      JOptionPane.showMessageDialog(this.ui, maxNumberOfContributorsError);
    }
    this.inputs.setDnaMassError("");
    this.inputs.setMaxNumberOfContributorsError("");
  }
  
  class NocitThread
    extends Thread
  {
    NocitThread() {}
    
    public void run()
    {
      NocitControl.this.runNocit();
    }
  }
}
