package Common;

import javax.swing.filechooser.FileFilter;
import java.io.File;
import java.util.TreeSet;



public class ExtensionFileFilter extends FileFilter
{
      /**
       * The set of extensions that are accepted.
       */
      TreeSet<String> extensions;
      String description;

      public ExtensionFileFilter()
      {
	 super();
	 extensions = new TreeSet<String>();
      }

      
      public void add(String an_extension)
      {
	 extensions.add(an_extension);
      }

    
      public boolean accept(File f) 
      {
	 if (f.isDirectory()) 
	    return true;
	       
	 String the_extension = getExtension(f.getName());
	 if(the_extension != null) 
	 {
	    if(extensions.contains(the_extension))
	       return true;
	    else 
	       return false;
	 }
	 return false;
      }

      /**
       * Returns the description of this filter
       */
      public String getDescription() 
      {
	 return description;
      }

      /**
       * Sets the description of this filter
       */
      public void setDescription(String description) 
      {
	 this.description = description;
      }


      
      public String getExtension(String file_name) 
      { 
	 String ext = null; 
	 int i = file_name.lastIndexOf('.'); 
	 if( i > 0 && i < file_name.length() - 1) 
	    ext = file_name.substring(i+1).toLowerCase(); 
	 return ext; 
      }
}
