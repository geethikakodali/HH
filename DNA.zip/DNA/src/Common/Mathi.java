package Common;



public class Mathi
{

      
      public static int pow(int x, int p)
      { 
	 int ret = 1; 
	 for( int i = 0; i < p; i++ ) 
	    ret *= x;
	 return ret; 
      }
}
