package Common;

import java.util.Collection;
import java.util.Iterator;



public class Algorithms
{

      
      public static int sum(Collection<Integer> collection)
      {
	 int result = 0;
	 Iterator<Integer> iter = collection.iterator();
	 while(iter.hasNext())
	    result += iter.next();
	 return result;
      }

     
      public static <T> int firstOccurrence(T[] an_unordered_array,
					    T to_look_for)
      {
	 for( int index = 0; index<an_unordered_array.length; index++ )
	    if( an_unordered_array[index].equals(to_look_for) )
	       return index;
	 return -1;		  
      }
}

