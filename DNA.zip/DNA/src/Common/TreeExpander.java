package Common;

import javax.swing.JTree;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;



public class TreeExpander
{

      public static int expandJTreeNode( JTree tree, TreeModel model,
					 Object node, int row, int depth )
      {
	 if (node != null  &&  !model.isLeaf(node)) {
	    tree.expandRow(row);
	    if (depth != 0)
	    {
	       for (int index = 0;
		    row + 1 < tree.getRowCount()  &&  
		       index < model.getChildCount(node);
		    index++)
	       {
		  row++;
		  Object child = model.getChild(node, index);
		  if (child == null)
		     break;
		  TreePath path;
		  while ((path = tree.getPathForRow(row)) != null  &&
			 path.getLastPathComponent() != child)
		     row++;
		  if (path == null)
		     break;
		  row = expandJTreeNode(tree, model, child, row, depth - 1);
	       }
	    }
	 }
	 return row;
      } // expandJTreeNode()
}
