package mining.classification.decesiontree;



import java.text.NumberFormat;
class ConditionOrdered extends Condition
{
      private Comparable theSplitValue;
      public ConditionOrdered(String attribut_name, Comparable theSplitValue)
      {
	 super(attribut_name);
	 this.theSplitValue = theSplitValue;
      }
      public String toString()
      {
	 NumberFormat pform = NumberFormat.getNumberInstance();

	 return super.toString() + " <= " + pform.format(theSplitValue);
      }

      public boolean meetsCondition(Object attribute_value)
      {
	 if( ((Comparable) attribute_value).compareTo(theSplitValue) > 0 )
	    return false;
	 else
	    return true;
      }
}
