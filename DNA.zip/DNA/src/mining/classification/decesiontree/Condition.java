
package mining.classification.decesiontree;
import java.io.Serializable;



abstract class Condition implements Serializable
{

      
      private String attribute_name;
      

      
      public Condition(String attribute_name)
      {
	 this.attribute_name = attribute_name;
      }

      
      public String getAttributeName()
      {
	 return attribute_name;
      }

      
      public String toString()
      {
	 return attribute_name;
      }

      
      public abstract boolean meetsCondition(Object attribute_value);
}

