package mining.classification.decesiontree;
import javax.swing.JFrame;



public class PredictUnseenPoint
{
      public static void main(String[] args)
      {
	 

	 String fileaskstring = "Please give the file that contains the "
	    + "decision tree. If default extension was used during "
	    + "the construction, than its extension is dtm (referring to"
	    + "decision tree model). ";

      	FirstFrame firstframe = 
	   new FirstFrame("predecting Values", fileaskstring, false );
      	firstframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      	firstframe.setLocationRelativeTo(null);
      	firstframe.setVisible(true);
      }
}
