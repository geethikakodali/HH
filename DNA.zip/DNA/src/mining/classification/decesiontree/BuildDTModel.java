package mining.classification.decesiontree;

import javax.swing.JFrame;



public class BuildDTModel
{
      public static void main(String[] args)
      {
	

	
          String fileaskstring="Please give the file that contains the training";

      	FirstFrame firstframe =	   new FirstFrame( "", fileaskstring, true );
      	//firstframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      	//firstframe.setLocationRelativeTo(null);
      	firstframe.setVisible(true);
      }
}

