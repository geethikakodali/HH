package mining.classification.decesiontree;



class TooMuchValueException extends Exception
{

      
      private String name_of_attribute;
      public TooMuchValueException(String name_of_attribute)
      {
	 this.name_of_attribute = name_of_attribute;
      }
      public String get_name_of_attribute()
      {
	 return name_of_attribute;
      }
}
