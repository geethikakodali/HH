
/*   2:    */ 
/*   3:    */ import java.awt.Color;
/*   4:    */ import java.awt.Dimension;
/*   5:    */ import java.awt.FlowLayout;
/*   6:    */ import java.awt.GridBagConstraints;
/*   7:    */ import java.awt.GridBagLayout;
/*   8:    */ import java.awt.Insets;
/*   9:    */ import java.awt.event.ActionListener;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import javax.swing.BorderFactory;
/*  12:    */ import javax.swing.BoxLayout;
/*  13:    */ import javax.swing.JButton;
/*  14:    */ import javax.swing.JFrame;
/*  15:    */ import javax.swing.JLabel;
/*  16:    */ import javax.swing.JPanel;
/*  17:    */ import javax.swing.JProgressBar;
/*  18:    */ import javax.swing.JTextField;
/*  19:    */ import javax.swing.border.EmptyBorder;
/*  20:    */ import javax.swing.border.EtchedBorder;
/*  21:    */ 
/*  22:    */ public class CEESItWindow
/*  23:    */   extends JFrame
/*  24:    */ {
/*  25:    */   private JPanel basePanel;
/*  26:    */   private JPanel filesPanel;
/*  27:    */   private JPanel numericInputPanel;
/*  28:    */   private JPanel DNAMassPanel;
/*  29:    */   private JPanel NumberContibutorsPanel;
/*  30:    */   private JPanel NumberSamplesPanel;
/*  31:    */   private JPanel thetaPanel;
/*  32:    */   private JPanel buttonsPanel;
/*  33:    */   private JPanel panelForFilesPanelBorder;
/*  34:    */   private JPanel progressBarPanel;
/*  35:    */   private JLabel calibrationFileLabel;
/*  36:    */   private JLabel sampleFileLabel;
/*  37:    */   private JLabel frequencyFileLabel;
/*  38:    */   private JLabel poiGenotypeFileLabel;
/*  39:    */   private JLabel outputFileLabel;
/*  40:    */   private JLabel DNAMassLabel;
/*  41:    */   private JLabel NumberContributorsLabel;
/*  42:    */   private JLabel NumberSamplesLabel;
/*  43:    */   private JLabel thetaLabel;
/*  44:    */   private JTextField DNAMassSelection;
/*  45:    */   private JTextField NumberContributorsSelection;
/*  46:    */   private JTextField NumberSamplesSelection;
/*  47:    */   private JTextField thetaSelection;
/*  48: 61 */   private final Dimension fileSelectionValueLabelDimension = new Dimension(200, 20);
/*  49:    */   private JLabel sampleFileSelectionValueLabel;
/*  50:    */   private JLabel frequencyFileSelectionValueLabel;
/*  51:    */   private JLabel poiGenotypeFileSelectionValueLabel;
/*  52:    */   private JLabel calibrationFileSelectionValueLabel;
/*  53:    */   private JLabel outputFileSelectionValueLabel;
/*  54:    */   private ArrayList<JButton> buttons;
/*  55:    */   private JProgressBar progressBar;
/*  56:    */   private JButton calibrationFileSelectionButton;
/*  57:    */   private JButton sampleFileSelectionButton;
/*  58:    */   private JButton frequencyFileSelectionButton;
/*  59:    */   private JButton poiGenotypeFileSelectionButton;
/*  60:    */   private JButton createOutputFileButton;
/*  61:    */   private JButton startButton;
/*  62:    */   private JButton stopButton;
/*  63:    */   
/*  64:    */   public CEESItWindow()
/*  65:    */   {
/*  66: 84 */     this.buttons = new ArrayList();
/*  67: 85 */     setupPanels();
/*  68: 86 */     setupFrame();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public CEESItWindow(ActionListener listener)
/*  72:    */   {
/*  73: 90 */     setupPanels();
/*  74: 91 */     setupFrame();
/*  75: 92 */     this.calibrationFileSelectionButton.addActionListener(listener);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public JButton getSampleFileSelectionButton()
/*  79:    */   {
/*  80: 96 */     return this.sampleFileSelectionButton;
/*  81:    */   }
/*  82:    */   
/*  83:    */   private void setupPanels()
/*  84:    */   {
/*  85:101 */     this.basePanel = new JPanel();
/*  86:102 */     this.basePanel.setOpaque(true);
/*  87:103 */     this.basePanel.setLayout(new BoxLayout(this.basePanel, 3));
/*  88:104 */     this.basePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
/*  89:    */     
/*  90:    */ 
/*  91:    */ 
/*  92:108 */     this.calibrationFileLabel = new JLabel("Calibration file: ");
/*  93:109 */     this.sampleFileLabel = new JLabel("Sample file:  ");
/*  94:110 */     this.outputFileLabel = new JLabel("Output file:");
/*  95:111 */     this.frequencyFileLabel = new JLabel("Frequency file:");
/*  96:112 */     this.poiGenotypeFileLabel = new JLabel("POI genotype file: ");
/*  97:113 */     this.DNAMassLabel = new JLabel("Sample DNA input:");
/*  98:114 */     this.NumberContributorsLabel = new JLabel("Number of contributors (1-3):");
/*  99:115 */     this.NumberSamplesLabel = new JLabel("Number of random simulated genotypes:");
/* 100:116 */     this.thetaLabel = new JLabel("Population substructure correction factor (theta):");
/* 101:    */     
/* 102:    */ 
/* 103:    */ 
/* 104:120 */     this.calibrationFileSelectionValueLabel = new JLabel(" ", 0);
/* 105:121 */     this.calibrationFileSelectionValueLabel.setName("calibrationFileSelection");
/* 106:122 */     this.calibrationFileSelectionValueLabel.setPreferredSize(this.fileSelectionValueLabelDimension);
/* 107:123 */     this.calibrationFileSelectionValueLabel.setBorder(new EtchedBorder());
/* 108:124 */     this.calibrationFileSelectionValueLabel.setOpaque(true);
/* 109:125 */     this.calibrationFileSelectionValueLabel.setBackground(Color.WHITE);
/* 110:    */     
/* 111:127 */     this.sampleFileSelectionValueLabel = new JLabel("", 0);
/* 112:128 */     this.sampleFileSelectionValueLabel.setName("sampleFileSelection");
/* 113:129 */     this.sampleFileSelectionValueLabel.setPreferredSize(this.fileSelectionValueLabelDimension);
/* 114:130 */     this.sampleFileSelectionValueLabel.setBorder(new EtchedBorder());
/* 115:131 */     this.sampleFileSelectionValueLabel.setOpaque(true);
/* 116:132 */     this.sampleFileSelectionValueLabel.setBackground(Color.WHITE);
/* 117:    */     
/* 118:134 */     this.frequencyFileSelectionValueLabel = new JLabel("", 0);
/* 119:135 */     this.frequencyFileSelectionValueLabel.setName("frequencyFileSelection");
/* 120:136 */     this.frequencyFileSelectionValueLabel.setPreferredSize(this.fileSelectionValueLabelDimension);
/* 121:137 */     this.frequencyFileSelectionValueLabel.setBorder(new EtchedBorder());
/* 122:138 */     this.frequencyFileSelectionValueLabel.setOpaque(true);
/* 123:139 */     this.frequencyFileSelectionValueLabel.setBackground(Color.WHITE);
/* 124:    */     
/* 125:141 */     this.poiGenotypeFileSelectionValueLabel = new JLabel("", 0);
/* 126:142 */     this.poiGenotypeFileSelectionValueLabel.setName("poiGenotypeFileSelection");
/* 127:143 */     this.poiGenotypeFileSelectionValueLabel.setPreferredSize(this.fileSelectionValueLabelDimension);
/* 128:144 */     this.poiGenotypeFileSelectionValueLabel.setBorder(new EtchedBorder());
/* 129:145 */     this.poiGenotypeFileSelectionValueLabel.setOpaque(true);
/* 130:146 */     this.poiGenotypeFileSelectionValueLabel.setBackground(Color.WHITE);
/* 131:    */     
/* 132:148 */     this.outputFileSelectionValueLabel = new JLabel("", 0);
/* 133:149 */     this.outputFileSelectionValueLabel.setName("outputFileSelection");
/* 134:150 */     this.outputFileSelectionValueLabel.setPreferredSize(this.fileSelectionValueLabelDimension);
/* 135:151 */     this.outputFileSelectionValueLabel.setBorder(new EtchedBorder());
/* 136:152 */     this.outputFileSelectionValueLabel.setOpaque(true);
/* 137:153 */     this.outputFileSelectionValueLabel.setBackground(Color.WHITE);
/* 138:    */     
/* 139:    */ 
/* 140:156 */     this.DNAMassSelection = new JTextField("", 5);
/* 141:157 */     this.DNAMassSelection.setName("DNAMassSelection");
/* 142:    */     
/* 143:159 */     this.NumberContributorsSelection = new JTextField("", 5);
/* 144:160 */     this.NumberContributorsSelection.setName("NumberContributorsSelection");
/* 145:    */     
/* 146:162 */     this.NumberSamplesSelection = new JTextField("1000000000", 8);
/* 147:163 */     this.NumberSamplesSelection.setName("NumberSamplesSelection");
/* 148:    */     
/* 149:165 */     this.thetaSelection = new JTextField("", 5);
/* 150:166 */     this.thetaSelection.setName("thetaSelection");
/* 151:    */     
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:173 */     this.calibrationFileSelectionButton = new JButton("Browse");
/* 158:174 */     this.calibrationFileSelectionButton.setActionCommand("calibration");
/* 159:175 */     this.buttons.add(this.calibrationFileSelectionButton);
/* 160:    */     
/* 161:177 */     this.sampleFileSelectionButton = new JButton("Browse");
/* 162:178 */     this.sampleFileSelectionButton.setActionCommand("sample");
/* 163:179 */     this.buttons.add(this.sampleFileSelectionButton);
/* 164:    */     
/* 165:181 */     this.frequencyFileSelectionButton = new JButton("Browse");
/* 166:182 */     this.frequencyFileSelectionButton.setActionCommand("frequency");
/* 167:183 */     this.buttons.add(this.frequencyFileSelectionButton);
/* 168:    */     
/* 169:185 */     this.poiGenotypeFileSelectionButton = new JButton("Browse");
/* 170:186 */     this.poiGenotypeFileSelectionButton.setActionCommand("poiGenotype");
/* 171:187 */     this.buttons.add(this.poiGenotypeFileSelectionButton);
/* 172:    */     
/* 173:189 */     this.createOutputFileButton = new JButton("Browse");
/* 174:190 */     this.createOutputFileButton.setActionCommand("output");
/* 175:191 */     this.buttons.add(this.createOutputFileButton);
/* 176:    */     
/* 177:    */ 
/* 178:194 */     this.startButton = new JButton("START");
/* 179:195 */     this.startButton.setActionCommand("start");
/* 180:196 */     this.buttons.add(this.startButton);
/* 181:    */     
/* 182:198 */     this.stopButton = new JButton("STOP");
/* 183:199 */     this.stopButton.setActionCommand("stop");
/* 184:200 */     this.buttons.add(this.stopButton);
/* 185:    */     
/* 186:    */ 
/* 187:203 */     this.DNAMassPanel = new JPanel();
/* 188:204 */     this.DNAMassPanel.setLayout(new FlowLayout(0));
/* 189:205 */     this.DNAMassPanel.add(this.DNAMassLabel);
/* 190:206 */     this.DNAMassPanel.add(this.DNAMassSelection);
/* 191:    */     
/* 192:208 */     this.NumberContibutorsPanel = new JPanel();
/* 193:209 */     this.NumberContibutorsPanel.setLayout(new FlowLayout(0));
/* 194:210 */     this.NumberContibutorsPanel.add(this.NumberContributorsLabel);
/* 195:211 */     this.NumberContibutorsPanel.add(this.NumberContributorsSelection);
/* 196:    */     
/* 197:213 */     this.NumberSamplesPanel = new JPanel();
/* 198:214 */     this.NumberSamplesPanel.setLayout(new FlowLayout(0));
/* 199:215 */     this.NumberSamplesPanel.add(this.NumberSamplesLabel);
/* 200:216 */     this.NumberSamplesPanel.add(this.NumberSamplesSelection);
/* 201:    */     
/* 202:218 */     this.thetaPanel = new JPanel();
/* 203:219 */     this.thetaPanel.setLayout(new FlowLayout(0));
/* 204:220 */     this.thetaPanel.add(this.thetaLabel);
/* 205:221 */     this.thetaPanel.add(this.thetaSelection);
/* 206:    */     
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:228 */     this.numericInputPanel = new JPanel();
/* 213:229 */     this.numericInputPanel.setLayout(new BoxLayout(this.numericInputPanel, 3));
/* 214:230 */     this.numericInputPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(10, 10, 5, 10), BorderFactory.createEtchedBorder()));
/* 215:231 */     this.numericInputPanel.add(this.DNAMassPanel);
/* 216:232 */     this.numericInputPanel.add(this.NumberContibutorsPanel);
/* 217:233 */     this.numericInputPanel.add(this.NumberSamplesPanel);
/* 218:234 */     this.numericInputPanel.add(this.thetaPanel);
/* 219:    */     
/* 220:    */ 
/* 221:    */ 
/* 222:    */ 
/* 223:239 */     this.filesPanel = new JPanel(new GridBagLayout());
/* 224:240 */     this.filesPanel.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
/* 225:241 */     GridBagConstraints c = new GridBagConstraints();
/* 226:    */     
/* 227:243 */     c.gridx = 0;
/* 228:244 */     c.gridy = 0;
/* 229:245 */     c.insets = new Insets(4, 4, 4, 4);
/* 230:246 */     c.fill = 0;
/* 231:    */     
/* 232:248 */     this.filesPanel.add(this.calibrationFileLabel, c);
/* 233:    */     
/* 234:250 */     c.gridy = 1;
/* 235:251 */     this.filesPanel.add(this.frequencyFileLabel, c);
/* 236:    */     
/* 237:253 */     c.gridy = 2;
/* 238:254 */     this.filesPanel.add(this.sampleFileLabel, c);
/* 239:    */     
/* 240:256 */     c.gridy = 3;
/* 241:257 */     this.filesPanel.add(this.poiGenotypeFileLabel, c);
/* 242:    */     
/* 243:259 */     c.gridy = 4;
/* 244:260 */     this.filesPanel.add(this.outputFileLabel, c);
/* 245:    */     
/* 246:262 */     c.gridx = 1;
/* 247:263 */     c.gridy = 0;
/* 248:264 */     c.fill = 1;
/* 249:    */     
/* 250:266 */     this.filesPanel.add(this.calibrationFileSelectionValueLabel, c);
/* 251:    */     
/* 252:268 */     c.gridy = 1;
/* 253:269 */     this.filesPanel.add(this.frequencyFileSelectionValueLabel, c);
/* 254:    */     
/* 255:271 */     c.gridy = 2;
/* 256:272 */     this.filesPanel.add(this.sampleFileSelectionValueLabel, c);
/* 257:    */     
/* 258:274 */     c.gridy = 3;
/* 259:275 */     this.filesPanel.add(this.poiGenotypeFileSelectionValueLabel, c);
/* 260:    */     
/* 261:277 */     c.gridy = 4;
/* 262:278 */     this.filesPanel.add(this.outputFileSelectionValueLabel, c);
/* 263:    */     
/* 264:280 */     c.gridx = 2;
/* 265:281 */     c.gridy = 0;
/* 266:282 */     c.fill = 0;
/* 267:283 */     this.filesPanel.add(this.calibrationFileSelectionButton, c);
/* 268:    */     
/* 269:285 */     c.gridy = 1;
/* 270:286 */     this.filesPanel.add(this.frequencyFileSelectionButton, c);
/* 271:    */     
/* 272:288 */     c.gridy = 2;
/* 273:289 */     this.filesPanel.add(this.sampleFileSelectionButton, c);
/* 274:    */     
/* 275:291 */     c.gridy = 3;
/* 276:292 */     this.filesPanel.add(this.poiGenotypeFileSelectionButton, c);
/* 277:    */     
/* 278:294 */     c.gridy = 4;
/* 279:295 */     this.filesPanel.add(this.createOutputFileButton, c);
/* 280:    */     
/* 281:297 */     this.panelForFilesPanelBorder = new JPanel();
/* 282:298 */     this.panelForFilesPanelBorder.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(5, 10, 5, 10), BorderFactory.createEtchedBorder()));
/* 283:299 */     this.panelForFilesPanelBorder.add(this.filesPanel);
/* 284:    */     
/* 285:    */ 
/* 286:302 */     this.progressBar = new JProgressBar();
/* 287:303 */     this.progressBar.setStringPainted(true);
/* 288:304 */     this.progressBar.setString("");
/* 289:305 */     this.progressBarPanel = new JPanel();
/* 290:306 */     this.progressBarPanel.add(this.progressBar);
/* 291:307 */     this.progressBarPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(5, 10, 5, 10), BorderFactory.createEtchedBorder()));
/* 292:    */     
/* 293:    */ 
/* 294:310 */     this.buttonsPanel = new JPanel();
/* 295:311 */     this.buttonsPanel.setLayout(new FlowLayout(1));
/* 296:312 */     this.buttonsPanel.setBorder(BorderFactory.createCompoundBorder(new EmptyBorder(5, 10, 10, 10), BorderFactory.createEtchedBorder()));
/* 297:313 */     this.buttonsPanel.add(this.startButton);
/* 298:314 */     this.buttonsPanel.add(this.stopButton);
/* 299:315 */     this.basePanel.add(this.panelForFilesPanelBorder);
/* 300:316 */     this.basePanel.add(this.numericInputPanel);
/* 301:317 */     this.basePanel.add(this.progressBarPanel);
/* 302:318 */     this.basePanel.add(this.buttonsPanel);
/* 303:    */   }
/* 304:    */   
/* 305:    */   private void setupFrame()
/* 306:    */   {
/* 307:322 */     setContentPane(this.basePanel);
/* 308:323 */     setDefaultCloseOperation(3);
/* 309:324 */     setResizable(false);
/* 310:325 */     setTitle("CEESIt");
/* 311:326 */     pack();
/* 312:    */   }
/* 313:    */   
/* 314:    */   public void addActionListenerToAllButtons(ActionListener listener)
/* 315:    */   {
/* 316:330 */     for (JButton b : this.buttons) {
/* 317:331 */       b.addActionListener(listener);
/* 318:    */     }
/* 319:    */   }
/* 320:    */   
/* 321:    */   public void setCalibrationFileSelectionText(String selection)
/* 322:    */   {
/* 323:339 */     this.calibrationFileSelectionValueLabel.setText(selection);
/* 324:    */   }
/* 325:    */   
/* 326:    */   public String getCalibrationFileSelectionText()
/* 327:    */   {
/* 328:343 */     return this.calibrationFileSelectionValueLabel.getText();
/* 329:    */   }
/* 330:    */   
/* 331:    */   public void setFrequencyFileSelectionText(String selection)
/* 332:    */   {
/* 333:347 */     this.frequencyFileSelectionValueLabel.setText(selection);
/* 334:    */   }
/* 335:    */   
/* 336:    */   public String getFrequencyFileSelectionText()
/* 337:    */   {
/* 338:351 */     return this.frequencyFileSelectionValueLabel.getText();
/* 339:    */   }
/* 340:    */   
/* 341:    */   public void setSampleFileSelectionText(String selection)
/* 342:    */   {
/* 343:355 */     this.sampleFileSelectionValueLabel.setText(selection);
/* 344:    */   }
/* 345:    */   
/* 346:    */   public String getSampleFileSelectionText()
/* 347:    */   {
/* 348:359 */     return this.sampleFileSelectionValueLabel.getText();
/* 349:    */   }
/* 350:    */   
/* 351:    */   public void setpoiGenotypeFileSelectionText(String selection)
/* 352:    */   {
/* 353:363 */     this.poiGenotypeFileSelectionValueLabel.setText(selection);
/* 354:    */   }
/* 355:    */   
/* 356:    */   public String getpoiGenotypeFileSelectionText()
/* 357:    */   {
/* 358:367 */     return this.poiGenotypeFileSelectionValueLabel.getText();
/* 359:    */   }
/* 360:    */   
/* 361:    */   public JProgressBar getProgressBar()
/* 362:    */   {
/* 363:371 */     return this.progressBar;
/* 364:    */   }
/* 365:    */   
/* 366:    */   public void setOutputFileSelectionText(String selection)
/* 367:    */   {
/* 368:375 */     this.outputFileSelectionValueLabel.setText(selection);
/* 369:    */   }
/* 370:    */   
/* 371:    */   public String getOutputFileSelectionText()
/* 372:    */   {
/* 373:379 */     return this.outputFileSelectionValueLabel.getText();
/* 374:    */   }
/* 375:    */   
/* 376:    */   public String getDNAMassSelectionText()
/* 377:    */   {
/* 378:383 */     return this.DNAMassSelection.getText();
/* 379:    */   }
/* 380:    */   
/* 381:    */   public String getNoContibutorsText()
/* 382:    */   {
/* 383:387 */     return this.NumberContributorsSelection.getText();
/* 384:    */   }
/* 385:    */   
/* 386:    */   public String getNumberSamplesText()
/* 387:    */   {
/* 388:391 */     return this.NumberSamplesSelection.getText();
/* 389:    */   }
/* 390:    */   
/* 391:    */   public String getThetaText()
/* 392:    */   {
/* 393:395 */     return this.thetaSelection.getText();
/* 394:    */   }
/* 395:    */   
/* 396:    */   public void setStartButtonEnabled(Boolean b)
/* 397:    */   {
/* 398:403 */     this.startButton.setEnabled(b.booleanValue());
/* 399:    */   }
/* 400:    */ }



/* Location:           C:\Users\Lunar\Downloads\CEESIt_App__Tutorial_v1.0 (1)\CEESIt App & Tutorial v1.0\CEESIt_v1.0\CEESIt_v1.jar

 * Qualified Name:     ceesit_v1.CEESItWindow

 * JD-Core Version:    0.7.0.1

 */