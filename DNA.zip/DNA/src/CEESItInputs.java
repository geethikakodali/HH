
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import javax.swing.JOptionPane;
/*   5:    */ 
/*   6:    */ public class CEESItInputs
/*   7:    */ {
/*   8: 18 */   private File calibrationFile = null;
/*   9: 19 */   private File frequencyFile = null;
/*  10: 20 */   private File sampleFile = null;
/*  11: 21 */   private File outputFile = null;
/*  12: 22 */   private File poiGenotypeFile = null;
/*  13: 25 */   private int NumberOfContributors = 0;
/*  14: 26 */   private double dnaMass = 0.0D;
/*  15: 27 */   private int numPValueSamples = 0;
/*  16: 28 */   private double theta = 0.0D;
/*  17: 32 */   private String dnaMassError = "";
/*  18: 33 */   private String NumberOfContributorsError = "";
/*  19: 34 */   private String NumberOfSamplesError = "";
/*  20: 35 */   private String thetaError = "";
/*  21:    */   
/*  22:    */   public boolean updateNumericFields(String mass, String NumberContributors, String NumSamples, String Theta)
/*  23:    */   {
/*  24: 47 */     boolean fieldsValid = true;
/*  25:    */     try
/*  26:    */     {
/*  27: 50 */       this.dnaMass = Double.parseDouble(mass);
/*  28:    */     }
/*  29:    */     catch (IllegalArgumentException e)
/*  30:    */     {
/*  31: 52 */       this.dnaMassError = "Invalid DNA mass value.";
/*  32: 53 */       fieldsValid = false;
/*  33:    */     }
/*  34:    */     try
/*  35:    */     {
/*  36: 57 */       this.NumberOfContributors = Integer.parseInt(NumberContributors);
/*  37:    */     }
/*  38:    */     catch (IllegalArgumentException e)
/*  39:    */     {
/*  40: 59 */       this.NumberOfContributorsError = "Invalid value for maximum number of contributors. ";
/*  41: 60 */       fieldsValid = false;
/*  42:    */     }
/*  43:    */     try
/*  44:    */     {
/*  45: 64 */       this.numPValueSamples = Integer.parseInt(NumSamples);
/*  46:    */     }
/*  47:    */     catch (IllegalArgumentException e)
/*  48:    */     {
/*  49: 66 */       this.NumberOfSamplesError = "Invalid value for number of p value samples. ";
/*  50: 67 */       fieldsValid = false;
/*  51:    */     }
/*  52:    */     try
/*  53:    */     {
/*  54: 71 */       this.theta = Double.parseDouble(Theta);
/*  55:    */     }
/*  56:    */     catch (IllegalArgumentException e)
/*  57:    */     {
/*  58: 73 */       this.thetaError = "Invalid value for theta. ";
/*  59: 74 */       fieldsValid = false;
/*  60:    */     }
/*  61: 84 */     return fieldsValid;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean allFieldsValid()
/*  65:    */   {
/*  66: 94 */     if (this.calibrationFile == null)
/*  67:    */     {
/*  68: 95 */       JOptionPane.showMessageDialog(null, "A calibration file was not provided");
/*  69: 96 */       return false;
/*  70:    */     }
/*  71: 99 */     if (this.frequencyFile == null)
/*  72:    */     {
/*  73:100 */       JOptionPane.showMessageDialog(null, "A frequency file was not provided");
/*  74:101 */       return false;
/*  75:    */     }
/*  76:104 */     if (this.sampleFile == null)
/*  77:    */     {
/*  78:105 */       JOptionPane.showMessageDialog(null, "A sample file was not provided");
/*  79:106 */       return false;
/*  80:    */     }
/*  81:109 */     if (this.poiGenotypeFile == null)
/*  82:    */     {
/*  83:110 */       JOptionPane.showMessageDialog(null, "A POI genotype file was not provided");
/*  84:111 */       return false;
/*  85:    */     }
/*  86:114 */     if (this.dnaMass < 0.0D)
/*  87:    */     {
/*  88:115 */       this.dnaMassError = "Invalid DNA mass value.";
/*  89:116 */       return false;
/*  90:    */     }
/*  91:119 */     if ((this.NumberOfContributors < 1) || (this.NumberOfContributors > 3))
/*  92:    */     {
/*  93:120 */       this.NumberOfContributorsError = "Invalid value for maximum number of contributors.";
/*  94:121 */       return false;
/*  95:    */     }
/*  96:124 */     if (this.numPValueSamples <= 0)
/*  97:    */     {
/*  98:125 */       this.NumberOfSamplesError = "Invalid value for number of p-value samples";
/*  99:126 */       return false;
/* 100:    */     }
/* 101:129 */     if (this.theta < 0.0D)
/* 102:    */     {
/* 103:130 */       this.thetaError = "Invalid value for theta";
/* 104:131 */       return false;
/* 105:    */     }
/* 106:140 */     return true;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void setDnaMassError(String error)
/* 110:    */   {
/* 111:147 */     this.dnaMassError = error;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void setNumberOfContributorsError(String error)
/* 115:    */   {
/* 116:151 */     this.NumberOfContributorsError = error;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setNumberOfSamplesError(String error)
/* 120:    */   {
/* 121:155 */     this.NumberOfSamplesError = error;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setThetaError(String error)
/* 125:    */   {
/* 126:163 */     this.thetaError = error;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void setCalibrationFile(File calibrationFile)
/* 130:    */   {
/* 131:167 */     this.calibrationFile = calibrationFile;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void setFrequencyFile(File frequencyFile)
/* 135:    */   {
/* 136:171 */     this.frequencyFile = frequencyFile;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public void setSampleFile(File sampleFile)
/* 140:    */   {
/* 141:175 */     this.sampleFile = sampleFile;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void setpoiGenotypeFile(File poiFile)
/* 145:    */   {
/* 146:179 */     this.poiGenotypeFile = poiFile;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void setOutputFile(File outputFile)
/* 150:    */   {
/* 151:183 */     this.outputFile = outputFile;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void setNumberOfContributors(int NumberOfContributors)
/* 155:    */   {
/* 156:187 */     this.NumberOfContributors = NumberOfContributors;
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void setNumberOfSamples(int NumberOfSamples)
/* 160:    */   {
/* 161:191 */     this.numPValueSamples = NumberOfSamples;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public void setDNAMass(double mass)
/* 165:    */   {
/* 166:195 */     this.dnaMass = mass;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public void setTheta(double Theta)
/* 170:    */   {
/* 171:203 */     this.theta = Theta;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public File getCalibrationFile()
/* 175:    */   {
/* 176:207 */     return this.calibrationFile;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public File getFrequencyFile()
/* 180:    */   {
/* 181:211 */     return this.frequencyFile;
/* 182:    */   }
/* 183:    */   
/* 184:    */   public File getSampleFile()
/* 185:    */   {
/* 186:215 */     return this.sampleFile;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public File getPOIFile()
/* 190:    */   {
/* 191:219 */     return this.poiGenotypeFile;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public File getOutputFile()
/* 195:    */   {
/* 196:223 */     return this.outputFile;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public int getNumberOfContributors()
/* 200:    */   {
/* 201:227 */     return this.NumberOfContributors;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public double getDNAMass()
/* 205:    */   {
/* 206:231 */     return this.dnaMass;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public double getTheta()
/* 210:    */   {
/* 211:239 */     return this.theta;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public int getNumPValueSamples()
/* 215:    */   {
/* 216:243 */     return this.numPValueSamples;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public String getDnaMassError()
/* 220:    */   {
/* 221:247 */     return this.dnaMassError;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public String getNumberOfContributorsError()
/* 225:    */   {
/* 226:251 */     return this.NumberOfContributorsError;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public String getNumberOfSamplesError()
/* 230:    */   {
/* 231:255 */     return this.NumberOfSamplesError;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public String getThetaError()
/* 235:    */   {
/* 236:259 */     return this.thetaError;
/* 237:    */   }
/* 238:    */ }



/* Location:           C:\Users\Lunar\Downloads\CEESIt_App__Tutorial_v1.0 (1)\CEESIt App & Tutorial v1.0\CEESIt_v1.0\CEESIt_v1.jar

 * Qualified Name:     ceesit_v1.CEESItInputs

 * JD-Core Version:    0.7.0.1

 */