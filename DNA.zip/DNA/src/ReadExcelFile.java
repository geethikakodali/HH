import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.Vector;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;

public class ReadExcelFile {

    public static void process(String args) throws IOException, ClassNotFoundException, SQLException {

       // String fileName = "d:\\denguedatabase.xls";
        String fileName=args;
        Vector dataHolder = ReadCSV(fileName);
        printCellDataToConsole(dataHolder);
    }

    public static Vector ReadCSV(String fileName) {
        Vector cellVectorHolder = new Vector();

        try {
            FileInputStream myInput = new FileInputStream(fileName);

            POIFSFileSystem myFileSystem = new POIFSFileSystem(myInput);

            HSSFWorkbook myWorkBook = new HSSFWorkbook(myFileSystem);

            HSSFSheet mySheet = myWorkBook.getSheetAt(0);

            Iterator rowIter = mySheet.rowIterator();

            while (rowIter.hasNext()) {
                HSSFRow myRow = (HSSFRow) rowIter.next();
                Iterator cellIter = myRow.cellIterator();
                Vector cellStoreVector = new Vector();
                while (cellIter.hasNext()) {
                    HSSFCell myCell = (HSSFCell) cellIter.next();
                    cellStoreVector.addElement(myCell);
                }
                cellVectorHolder.addElement(cellStoreVector);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cellVectorHolder;
    }

    private static void printCellDataToConsole(Vector dataHolder) throws IOException, ClassNotFoundException, SQLException {
        //LinkedList<String> row = new LinkedList<>;
        Class.forName("com.mysql.jdbc.Driver");
           Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/DNA","root","root");
            Statement st=con.createStatement();
            st.executeUpdate("truncate table dataset");
        String arry[] = new String[13];
        Vector row = new Vector();
        //FileWriter fw=new FileWriter("d://data.txt",true);
       // BufferedWriter bw=new BufferedWriter(fw);
       // System.out.println(dataHolder.size());
        for (int i = 1; i < dataHolder.size()-1; i++) {
            Vector cellStoreVector = (Vector) dataHolder.elementAt(i);
            for (int j = 0; j < cellStoreVector.size(); j++) {
                HSSFCell myCell = (HSSFCell) cellStoreVector.elementAt(j);
                String stringCellValue = myCell.toString();
                System.out.print(stringCellValue + "\t\t");
             //   bw.append(stringCellValue);
              //  int k=stringCellValue.length();
              //  arry=new String[k];
              //  System.out.println("hello"+k);
                arry[j]=stringCellValue;
                
            }
            System.out.println(arry[0]);
            System.out.println(arry[1]);
            System.out.println(arry[2]);
            System.out.println(arry[3]);
            System.out.println(arry[4]);
            System.out.println(arry[5]);
            System.out.println(arry[6]);
            System.out.println(arry[7]);
            System.out.println(arry[8]);
            System.out.println(arry[9]);
            System.out.println(arry[10]);
            System.out.println(arry[11]);
            System.out.println(arry[12]);
           /* System.out.println(arry[13]);
            System.out.println(arry[14]);
            System.out.println(arry[15]);
            System.out.println(arry[16]);*/
            
            System.out.println(arry[16]);
            
            st.executeUpdate("insert into dataset values('"+arry[0]+"','"+arry[1]+"','"+arry[2]+"','"+arry[3]+"','"+arry[4]+"','"+arry[5]+"','"+arry[6]+"','"+arry[7]+"','"+arry[8]+"','"+arry[9]+"','"+arry[10]+"','"+arry[11]+"','"+arry[12]+"')");
            
            System.out.println();
              //  bw.append("\n");
            
        }
       // bw.close();
//    fw.close();
    }
   
}